// cmd/genpwd/main.go
// Tool untuk generate bcrypt hash dari password admin.
//
// Usage:
//
//	go run cmd/genpwd/main.go mysecretpassword
//
// Output hash-nya di-paste ke .env sebagai ADMIN_PASSWORD_HASH.
package main

import (
	"fmt"
	"os"

	"golang.org/x/crypto/bcrypt"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "Usage: go run cmd/genpwd/main.go <password>")
		os.Exit(1)
	}

	password := os.Args[1]
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}

	fmt.Println(string(hash))
}
