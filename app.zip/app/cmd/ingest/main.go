package main

import (
	"context"
	"flag"
	"fmt"
	"os"

	"wa-ai/config"
	"wa-ai/logger"
	"wa-ai/rag"
	"wa-ai/store"

	"go.uber.org/zap"
)

func main() {
	clientID := flag.String("client", "", "Client ID (required)")
	filePath := flag.String("file", "", "Path ke file knowledge base (required)")
	flag.Parse()

	if *clientID == "" || *filePath == "" {
		fmt.Println("Usage: go run cmd/ingest/main.go -client <client_id> -file <file_path>")
		os.Exit(1)
	}

	config.Load()
	logger.Init(config.C.AppEnv)
	defer logger.Sync()

	store.InitRedis(config.C.RedisAddr)
	store.InitQdrant()

	ctx := context.Background()

	// Cek plan & doc limit
	plan := store.GetPlan(ctx, *clientID)
	allowed, err := store.IsDocAllowed(ctx, *clientID)
	if err != nil {
		logger.Fatal("Failed to check doc limit", zap.Error(err))
	}
	if !allowed {
		count, _ := store.GetDocCount(ctx, *clientID)
		logger.Fatal("Doc limit reached",
			zap.String("client", *clientID),
			zap.String("plan", plan.Name),
			zap.Int64("current", count),
			zap.Int("max", plan.MaxDocs),
		)
	}

	// Baca file
	logger.Info("Reading file", zap.String("path", *filePath))
	data, err := os.ReadFile(*filePath)
	if err != nil {
		logger.Fatal("Failed to read file", zap.Error(err))
	}

	text := string(data)
	logger.Info("File loaded",
		zap.String("client", *clientID),
		zap.Int("bytes", len(data)),
	)

	// Ingest
	logger.Info("Ingesting document...")
	err = rag.IngestDocument(ctx, *clientID, text)
	if err != nil {
		logger.Fatal("Failed to ingest document", zap.Error(err))
	}

	// Increment doc count
	count, err := store.IncrementDocCount(ctx, *clientID)
	if err != nil {
		logger.Error("Failed to increment doc count", zap.Error(err))
	}

	logger.Info("Document ingested successfully!",
		zap.String("client", *clientID),
		zap.String("file", *filePath),
		zap.String("plan", plan.Name),
		zap.Int64("doc_count", count),
		zap.Int("max_docs", plan.MaxDocs),
	)
}
