package main

import (
	"net/http"

	"wa-ai/config"
	"wa-ai/dashboard"
	"wa-ai/logger"
	"wa-ai/queue"
	"wa-ai/store"
	"wa-ai/usage"

	"go.uber.org/zap"
)

func main() {
	config.Load()
	logger.Init(config.C.AppEnv)
	defer logger.Sync()

	store.InitRedis(config.C.RedisAddr)
	store.InitQdrant()
	usage.InitRedis(config.C.RedisAddr)

	// Wajib diinit supaya queue.Publish() tidak panic
	// saat pesan WA masuk dari sesi yang di-start via dashboard
	queue.InitRedis(config.C.RedisAddr)

	logger.Info("Dashboard starting", zap.String("addr", ":8080"))

	srv := dashboard.NewServer()
	if err := http.ListenAndServe(":8080", srv); err != nil {
		logger.Fatal("Dashboard failed", zap.Error(err))
	}
}
