package whatsapp

import (
	"context"

	"wa-ai/logger"

	waProto "go.mau.fi/whatsmeow/binary/proto"
	"go.mau.fi/whatsmeow/types"
	"go.uber.org/zap"

	"go.mau.fi/whatsmeow"
	"google.golang.org/protobuf/proto"
)

func sendWAMessage(ctx context.Context, client *whatsmeow.Client, phone string, message string) error {
	jid, err := types.ParseJID(phone)
	if err != nil {
		// Coba parse sebagai nomor biasa
		jid, err = types.ParseJID(phone + "@s.whatsapp.net")
		if err != nil {
			logger.Error("Invalid JID", zap.String("phone", phone), zap.Error(err))
			return err
		}
	}

	_, err = client.SendMessage(ctx, jid, &waProto.Message{
		Conversation: proto.String(message),
	})
	if err != nil {
		logger.Error("Failed to send message", zap.Error(err))
		return err
	}

	logger.Info("Message sent", zap.String("to", phone))
	return nil
}
