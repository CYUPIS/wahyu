package whatsapp

import (
	"context"
	"fmt"
	"os"
	"sync"
	"time"

	"wa-ai/config"
	"wa-ai/logger"

	_ "github.com/mattn/go-sqlite3"
	"go.mau.fi/whatsmeow"
	"go.mau.fi/whatsmeow/store/sqlstore"
	waLog "go.mau.fi/whatsmeow/util/log"
	"go.uber.org/zap"
)

// QREvent dikirim ke channel saat QR baru tersedia atau status berubah.
type QREvent struct {
	Type string // "qr" | "connected" | "timeout" | "error"
	Code string // QR string, hanya diisi kalau Type == "qr"
}

type ClientSession struct {
	ClientID string
	Client   *whatsmeow.Client
}

var (
	sessions = map[string]*ClientSession{}
	mu       sync.RWMutex
)

// StartSession memulai sesi WA untuk clientID.
// QR events dikirim ke channel qrChan — caller bertanggung jawab membaca channel ini.
// Fungsi ini NON-BLOCKING — langsung return setelah goroutine dimulai.
// Channel qrChan akan di-close otomatis setelah connected atau error.
func StartSession(ctx context.Context, clientID string, qrChan chan<- QREvent) {
	go func() {
		defer close(qrChan)

		if err := startSessionInternal(ctx, clientID, qrChan); err != nil {
			logger.Error("Session error",
				zap.String("client", clientID),
				zap.Error(err),
			)
			select {
			case qrChan <- QREvent{Type: "error", Code: err.Error()}:
			default:
			}
		}
	}()
}

// StartSessionBlocking dipakai saat startup untuk client yang sudah pernah login.
// Tidak perlu QR karena session sudah tersimpan di SQLite.
func StartSessionBlocking(ctx context.Context, clientID string) error {
	qrChan := make(chan QREvent, 10)
	go func() {
		for range qrChan {
		}
	}()
	return startSessionInternal(ctx, clientID, qrChan)
}

func startSessionInternal(ctx context.Context, clientID string, qrChan chan<- QREvent) error {
	sessionPath := fmt.Sprintf("%s/%s/wa.db", config.C.SessionDir, clientID)

	dir := fmt.Sprintf("%s/%s", config.C.SessionDir, clientID)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}

	dbLog := waLog.Stdout("Database", "ERROR", true)
	container, err := sqlstore.New(ctx, "sqlite3",
		fmt.Sprintf("file:%s?_foreign_keys=on", sessionPath),
		dbLog,
	)
	if err != nil {
		return err
	}

	deviceStore, err := container.GetFirstDevice(ctx)
	if err != nil {
		return err
	}

	clientLog := waLog.Stdout("Client", "ERROR", true)
	waClient := whatsmeow.NewClient(deviceStore, clientLog)
	// Skip sinkronisasi app state (contacts, chats) saat reconnect
	// Ini mempercepat startup signifikan untuk nomor dengan banyak chat history
	waClient.AutomaticMessageRerequestFromPhone = false
	waClient.AddEventHandler(makeEventHandler(clientID))

	// Kalau sudah pernah login, langsung connect + pasang auto-reconnect
	if waClient.Store.ID != nil {
		if err := waClient.Connect(); err != nil {
			return err
		}

		mu.Lock()
		sessions[clientID] = &ClientSession{ClientID: clientID, Client: waClient}
		mu.Unlock()

		logger.Info("WhatsApp reconnected (existing session)", zap.String("client", clientID))
		select {
		case qrChan <- QREvent{Type: "connected"}:
		default:
		}

		// Monitor koneksi dan auto-reconnect kalau putus
		go watchConnection(ctx, clientID, waClient)

		return nil
	}

	// Belum pernah login — perlu QR
	maxRetry := 3
	for attempt := 0; attempt < maxRetry; attempt++ {
		waQRChan, _ := waClient.GetQRChannel(ctx)
		if err := waClient.Connect(); err != nil {
			return err
		}

		timedOut := false
		for evt := range waQRChan {
			switch evt.Event {
			case "code":
				logger.Info("QR generated", zap.String("client", clientID))
				select {
				case qrChan <- QREvent{Type: "qr", Code: evt.Code}:
				case <-ctx.Done():
					return ctx.Err()
				}
			case "success":
				// Scan berhasil
			case "timeout":
				timedOut = true
			}
		}

		if waClient.Store.ID != nil {
			mu.Lock()
			sessions[clientID] = &ClientSession{ClientID: clientID, Client: waClient}
			mu.Unlock()

			logger.Info("WhatsApp connected", zap.String("client", clientID))
			select {
			case qrChan <- QREvent{Type: "connected"}:
			default:
			}

			// Monitor koneksi setelah QR scan berhasil
			go watchConnection(ctx, clientID, waClient)

			return nil
		}

		if timedOut && attempt < maxRetry-1 {
			logger.Warn("QR timeout, retrying",
				zap.String("client", clientID),
				zap.Int("attempt", attempt+1),
			)
			select {
			case qrChan <- QREvent{Type: "timeout"}:
			default:
			}
			waClient.Disconnect()
			time.Sleep(2 * time.Second)
		}
	}

	return fmt.Errorf("QR scan timeout setelah %d percobaan", maxRetry)
}

// watchConnection memonitor koneksi WA dan auto-reconnect dengan exponential backoff.
// Jalan di goroutine terpisah setelah session berhasil connect.
func watchConnection(ctx context.Context, clientID string, waClient *whatsmeow.Client) {
	backoff := 5 * time.Second
	maxBackoff := 5 * time.Minute

	for {
		select {
		case <-ctx.Done():
			return
		case <-time.After(30 * time.Second):
			// Cek koneksi setiap 30 detik
			if waClient.IsConnected() {
				backoff = 5 * time.Second // reset backoff kalau koneksi sehat
				continue
			}

			// Koneksi putus — coba reconnect
			logger.Warn("WhatsApp disconnected, attempting reconnect",
				zap.String("client", clientID),
				zap.Duration("backoff", backoff),
			)

			if err := waClient.Connect(); err != nil {
				logger.Error("Reconnect failed",
					zap.String("client", clientID),
					zap.Error(err),
					zap.Duration("next_retry", backoff),
				)

				// Tunggu sebelum retry berikutnya
				select {
				case <-ctx.Done():
					return
				case <-time.After(backoff):
				}

				// Exponential backoff — max 5 menit
				backoff *= 2
				if backoff > maxBackoff {
					backoff = maxBackoff
				}
				continue
			}

			logger.Info("WhatsApp reconnected successfully",
				zap.String("client", clientID),
			)
			backoff = 5 * time.Second // reset backoff setelah berhasil
		}
	}
}

func StopSession(clientID string) {
	mu.Lock()
	defer mu.Unlock()

	if session, ok := sessions[clientID]; ok {
		session.Client.Disconnect()
		delete(sessions, clientID)
		logger.Info("WhatsApp disconnected", zap.String("client", clientID))
	}
}

func StopAll() {
	mu.Lock()
	defer mu.Unlock()

	for clientID, session := range sessions {
		session.Client.Disconnect()
		logger.Info("WhatsApp disconnected", zap.String("client", clientID))
	}
	sessions = map[string]*ClientSession{}
}

func IsConnected(clientID string) bool {
	mu.RLock()
	defer mu.RUnlock()
	s, ok := sessions[clientID]
	return ok && s.Client.IsConnected()
}

func SendMessage(ctx context.Context, clientID string, phone string, message string) error {
	mu.RLock()
	session, ok := sessions[clientID]
	mu.RUnlock()

	if !ok {
		return fmt.Errorf("client %s tidak ditemukan", clientID)
	}

	return sendWAMessage(ctx, session.Client, phone, message)
}

func GetActiveClients() []string {
	mu.RLock()
	defer mu.RUnlock()

	var clients []string
	for clientID := range sessions {
		clients = append(clients, clientID)
	}
	return clients
}
