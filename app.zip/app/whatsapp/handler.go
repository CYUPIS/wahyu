package whatsapp

import (
	"context"
	"time"

	"wa-ai/logger"
	"wa-ai/queue"
	"wa-ai/store"

	"go.mau.fi/whatsmeow/types/events"
	"go.uber.org/zap"
)

var allowedServers = map[string]bool{
	"s.whatsapp.net": true,
	"lid":            true,
}

// extractText mencoba mengambil teks dari berbagai tipe pesan WA.
// GetConversation() hanya menangkap pesan plain text biasa.
// Tipe lain (reply, extended, mention) perlu di-handle sendiri.
func extractText(msg *events.Message) string {
	m := msg.Message

	// 1. Plain text biasa
	if text := m.GetConversation(); text != "" {
		return text
	}

	// 2. Extended text message (link preview, reply, dll)
	if ext := m.GetExtendedTextMessage(); ext != nil {
		if text := ext.GetText(); text != "" {
			return text
		}
	}

	// 3. Ephemeral (pesan yang bisa hilang)
	if ep := m.GetEphemeralMessage(); ep != nil {
		if inner := ep.GetMessage(); inner != nil {
			if text := inner.GetConversation(); text != "" {
				return text
			}
			if ext := inner.GetExtendedTextMessage(); ext != nil {
				return ext.GetText()
			}
		}
	}

	// 4. View once message
	if vo := m.GetViewOnceMessage(); vo != nil {
		if inner := vo.GetMessage(); inner != nil {
			if text := inner.GetConversation(); text != "" {
				return text
			}
		}
	}

	return ""
}

func makeEventHandler(clientID string) func(interface{}) {
	return func(evt interface{}) {
		switch v := evt.(type) {
		case *events.Message:
			if v.Info.IsFromMe || v.Info.IsGroup {
				return
			}

			if !allowedServers[v.Info.Chat.Server] {
				logger.Warn("Message from unknown server — skipped",
					zap.String("client", clientID),
					zap.String("server", v.Info.Chat.Server),
					zap.String("from", v.Info.Chat.String()),
				)
				return
			}

			msg := extractText(v)
			if msg == "" {
				// Log supaya kita tahu ada pesan yang tidak bisa di-extract
				logger.Warn("Message has no extractable text — skipped",
					zap.String("client", clientID),
					zap.String("from", v.Info.Chat.String()),
				)
				return
			}

			sender := v.Info.Chat.String()

			logger.Info("Message received",
				zap.String("client", clientID),
				zap.String("from", sender),
				zap.String("push_name", v.Info.PushName),
				zap.String("text", msg),
			)

			// Track kontak untuk CRM
			store.TrackContact(context.Background(), clientID, sender, v.Info.PushName)

			err := queue.Publish(context.Background(), queue.Message{
				Sender:    sender,
				Text:      msg,
				ClientID:  clientID,
				Timestamp: time.Now(),
			})
			if err != nil {
				logger.Error("Failed to enqueue message", zap.Error(err))
			}
		}
	}
}
