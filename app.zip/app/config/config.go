package config

import (
	"log"
	"os"

	"github.com/joho/godotenv"
)

type Config struct {
	// WhatsApp
	SessionDir string

	// Redis
	RedisAddr string

	// Qdrant
	QdrantAddr string

	// OpenRouter
	OpenRouterKey  string
	EmbeddingModel string
	LLMModel       string

	// App
	AppEnv string
}

var C Config

func Load() {
	err := godotenv.Load()
	if err != nil {
		log.Println("No .env file found, reading from environment")
	}

	C = Config{
		SessionDir:     getEnv("SESSION_DIR", "./sessions"),
		RedisAddr:      getEnv("REDIS_ADDR", "localhost:6379"),
		QdrantAddr:     getEnv("QDRANT_ADDR", "localhost:6333"),
		OpenRouterKey:  getEnv("OPENROUTER_KEY", ""),
		EmbeddingModel: getEnv("EMBEDDING_MODEL", "openai/text-embedding-3-small"),
		LLMModel:       getEnv("LLM_MODEL", "qwen/qwen-2.5-7b-instruct"),
		AppEnv:         getEnv("APP_ENV", "development"),
	}

	if C.OpenRouterKey == "" {
		log.Fatal("OPENROUTER_KEY is required")
	}
}

func getEnv(key, fallback string) string {
	if val, ok := os.LookupEnv(key); ok {
		return val
	}
	return fallback
}
