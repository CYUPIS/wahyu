package store

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"wa-ai/config"
	"wa-ai/logger"

	"go.uber.org/zap"
)

type QdrantClient struct {
	baseURL    string
	httpClient *http.Client
}

type Point struct {
	ID      string                 `json:"id"`
	Vector  []float32              `json:"vector"`
	Payload map[string]interface{} `json:"payload"`
}

type SearchResult struct {
	ID      string                 `json:"id"`
	Score   float32                `json:"score"`
	Payload map[string]interface{} `json:"payload"`
}

var Qdrant *QdrantClient

func InitQdrant() {
	Qdrant = &QdrantClient{
		baseURL: "http://" + config.C.QdrantAddr,
		// Timeout 10 detik — mencegah goroutine hang kalau Qdrant lambat/mati
		httpClient: &http.Client{
			Timeout: 10 * time.Second,
		},
	}
	logger.Info("Qdrant client initialized", zap.String("addr", config.C.QdrantAddr))
}

func (q *QdrantClient) CreateCollection(ctx context.Context, name string, dimension int) error {
	body := map[string]interface{}{
		"vectors": map[string]interface{}{
			"size":     dimension,
			"distance": "Cosine",
		},
	}

	data, _ := json.Marshal(body)
	req, err := http.NewRequestWithContext(ctx, "PUT",
		fmt.Sprintf("%s/collections/%s", q.baseURL, name),
		bytes.NewBuffer(data),
	)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := q.httpClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode == 409 {
		// Collection sudah ada, skip
		return nil
	}

	logger.Info("Collection created", zap.String("name", name))
	return nil
}

func (q *QdrantClient) Upsert(ctx context.Context, collection string, points []Point) error {
	body := map[string]interface{}{
		"points": points,
	}

	data, _ := json.Marshal(body)
	req, err := http.NewRequestWithContext(ctx, "PUT",
		fmt.Sprintf("%s/collections/%s/points", q.baseURL, collection),
		bytes.NewBuffer(data),
	)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := q.httpClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	body2, _ := io.ReadAll(resp.Body)
	logger.Info("Points upserted",
		zap.String("collection", collection),
		zap.Int("count", len(points)),
		zap.String("response", string(body2)),
	)
	return nil
}

func (q *QdrantClient) Search(ctx context.Context, collection string, vector []float32, limit int) ([]SearchResult, error) {
	body := map[string]interface{}{
		"vector":       vector,
		"limit":        limit,
		"with_payload": true,
	}

	data, _ := json.Marshal(body)
	req, err := http.NewRequestWithContext(ctx, "POST",
		fmt.Sprintf("%s/collections/%s/points/search", q.baseURL, collection),
		bytes.NewBuffer(data),
	)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := q.httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result struct {
		Result []struct {
			ID      interface{}            `json:"id"`
			Score   float32                `json:"score"`
			Payload map[string]interface{} `json:"payload"`
		} `json:"result"`
	}

	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}

	var results []SearchResult
	for _, r := range result.Result {
		results = append(results, SearchResult{
			ID:      fmt.Sprintf("%v", r.ID),
			Score:   r.Score,
			Payload: r.Payload,
		})
	}

	return results, nil
}

func (q *QdrantClient) DeleteByDocID(ctx context.Context, collection string, docID string) error {
	body := map[string]interface{}{
		"filter": map[string]interface{}{
			"must": []map[string]interface{}{
				{
					"key":   "doc_id",
					"match": map[string]interface{}{"value": docID},
				},
			},
		},
	}

	data, _ := json.Marshal(body)
	req, err := http.NewRequestWithContext(ctx, "POST",
		fmt.Sprintf("%s/collections/%s/points/delete", q.baseURL, collection),
		bytes.NewBuffer(data),
	)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := q.httpClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	logger.Info("Points deleted by doc_id",
		zap.String("collection", collection),
		zap.String("doc_id", docID),
	)
	return nil
}
