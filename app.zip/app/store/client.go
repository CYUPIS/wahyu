package store

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"time"

	"github.com/redis/go-redis/v9"
	"golang.org/x/crypto/bcrypt"
)

var rdb *redis.Client

func InitRedis(addr string) {
	rdb = redis.NewClient(&redis.Options{
		Addr: addr,
	})
}

// Plan config
type Plan struct {
	Name        string
	MaxMessages int
	MaxDocs     int
	MaxHistory  int
}

var Plans = map[string]Plan{
	"basic": {
		Name:        "Basic Starter",
		MaxMessages: 200,
		MaxDocs:     5,
		MaxHistory:  5,
	},
	"standard": {
		Name:        "Standard",
		MaxMessages: 600,
		MaxDocs:     15,
		MaxHistory:  15,
	},
	"pro": {
		Name:        "Pro Business",
		MaxMessages: 1500,
		MaxDocs:     50,
		MaxHistory:  30,
	},
}

// System prompt
func SetSystemPrompt(ctx context.Context, clientID string, prompt string) error {
	key := fmt.Sprintf("client:%s:system_prompt", clientID)
	return rdb.Set(ctx, key, prompt, 0).Err()
}

func GetSystemPrompt(ctx context.Context, clientID string) (string, error) {
	key := fmt.Sprintf("client:%s:system_prompt", clientID)
	val, err := rdb.Get(ctx, key).Result()
	if err == redis.Nil {
		return "Kamu adalah asisten virtual yang membantu menjawab pertanyaan pelanggan dengan ramah dan informatif.", nil
	}
	return val, err
}

// Plan per client
func SetPlan(ctx context.Context, clientID string, plan string) error {
	key := fmt.Sprintf("client:%s:plan", clientID)
	return rdb.Set(ctx, key, plan, 0).Err()
}

func GetPlan(ctx context.Context, clientID string) Plan {
	key := fmt.Sprintf("client:%s:plan", clientID)
	val, err := rdb.Get(ctx, key).Result()
	if err != nil {
		return Plans["basic"] // default basic
	}
	plan, ok := Plans[val]
	if !ok {
		return Plans["basic"]
	}
	return plan
}

// Chat history per user per client
type ChatMessage struct {
	Role      string    `json:"role"` // "user" atau "assistant"
	Content   string    `json:"content"`
	Timestamp time.Time `json:"timestamp"`
}

func AddChatHistory(ctx context.Context, clientID string, userJID string, role string, content string) error {
	key := fmt.Sprintf("history:%s:%s", clientID, userJID)

	msg := ChatMessage{
		Role:      role,
		Content:   content,
		Timestamp: time.Now(),
	}

	data, err := json.Marshal(msg)
	if err != nil {
		return err
	}

	// Push ke list
	err = rdb.RPush(ctx, key, string(data)).Err()
	if err != nil {
		return err
	}

	// Set expiry 24 jam
	rdb.Expire(ctx, key, 30*24*time.Hour)

	return nil
}

func GetChatHistory(ctx context.Context, clientID string, userJID string, maxHistory int) ([]ChatMessage, error) {
	key := fmt.Sprintf("history:%s:%s", clientID, userJID)

	// Ambil N pesan terakhir
	results, err := rdb.LRange(ctx, key, int64(-maxHistory), -1).Result()
	if err != nil {
		return nil, err
	}

	var messages []ChatMessage
	for _, r := range results {
		var msg ChatMessage
		if err := json.Unmarshal([]byte(r), &msg); err != nil {
			continue
		}
		messages = append(messages, msg)
	}

	return messages, nil
}

func ClearChatHistory(ctx context.Context, clientID string, userJID string) error {
	key := fmt.Sprintf("history:%s:%s", clientID, userJID)
	return rdb.Del(ctx, key).Err()
}

// Doc count tracking
func GetDocCount(ctx context.Context, clientID string) (int64, error) {
	key := fmt.Sprintf("client:%s:doc_count", clientID)
	val, err := rdb.Get(ctx, key).Result()
	if err == redis.Nil {
		return 0, nil
	}
	if err != nil {
		return 0, err
	}
	var count int64
	fmt.Sscanf(val, "%d", &count)
	return count, nil
}

func IncrementDocCount(ctx context.Context, clientID string) (int64, error) {
	key := fmt.Sprintf("client:%s:doc_count", clientID)
	return rdb.Incr(ctx, key).Result()
}

func IsDocAllowed(ctx context.Context, clientID string) (bool, error) {
	plan := GetPlan(ctx, clientID)
	count, err := GetDocCount(ctx, clientID)
	if err != nil {
		return false, err
	}
	return int(count) < plan.MaxDocs, nil
}

// Register & list clients
func RegisterClient(ctx context.Context, clientID string) error {
	return rdb.SAdd(ctx, "clients", clientID).Err()
}

func ListClients(ctx context.Context) ([]string, error) {
	return rdb.SMembers(ctx, "clients").Result()
}

// Document tracking
type Document struct {
	ID        string    `json:"id"`
	Filename  string    `json:"filename"`
	Chunks    int       `json:"chunks"`
	CreatedAt time.Time `json:"created_at"`
}

func AddDocument(ctx context.Context, clientID string, doc Document) error {
	key := fmt.Sprintf("client:%s:docs", clientID)
	data, err := json.Marshal(doc)
	if err != nil {
		return err
	}
	return rdb.HSet(ctx, key, doc.ID, string(data)).Err()
}

func ListDocuments(ctx context.Context, clientID string) ([]Document, error) {
	key := fmt.Sprintf("client:%s:docs", clientID)
	result, err := rdb.HGetAll(ctx, key).Result()
	if err != nil {
		return nil, err
	}

	var docs []Document
	for _, v := range result {
		var doc Document
		if err := json.Unmarshal([]byte(v), &doc); err != nil {
			continue
		}
		docs = append(docs, doc)
	}

	// Sort by created_at
	sort.Slice(docs, func(i, j int) bool {
		return docs[i].CreatedAt.Before(docs[j].CreatedAt)
	})

	return docs, nil
}

func DeleteDocument(ctx context.Context, clientID string, docID string) error {
	key := fmt.Sprintf("client:%s:docs", clientID)
	return rdb.HDel(ctx, key, docID).Err()
}

func DecrementDocCount(ctx context.Context, clientID string) {
	key := fmt.Sprintf("client:%s:doc_count", clientID)
	val, err := rdb.Decr(ctx, key).Result()
	if err == nil && val < 0 {
		rdb.Set(ctx, key, 0, 0)
	}
}

// Client portal auth
func SetClientPassword(ctx context.Context, clientID string, password string) error {
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return fmt.Errorf("failed to hash password: %w", err)
	}
	key := fmt.Sprintf("client:%s:password", clientID)
	return rdb.Set(ctx, key, string(hash), 0).Err()
}

// CheckClientPassword membandingkan password input dengan hash yang tersimpan.
// Return (true, nil) jika cocok, (false, nil) jika salah, (false, err) jika ada error Redis.
func CheckClientPassword(ctx context.Context, clientID string, input string) (bool, error) {
	key := fmt.Sprintf("client:%s:password", clientID)
	hash, err := rdb.Get(ctx, key).Result()
	if err == redis.Nil {
		return false, nil // client tidak punya password
	}
	if err != nil {
		return false, err
	}
	err = bcrypt.CompareHashAndPassword([]byte(hash), []byte(input))
	return err == nil, nil
}

// ── Session Store (admin & client portal) ──────────

// SetAdminSession menyimpan token sesi admin ke Redis dengan TTL.
func SetAdminSession(ctx context.Context, key string, username string, ttl time.Duration) error {
	return rdb.Set(ctx, key, username, ttl).Err()
}

// SetClientSession menyimpan token sesi client portal ke Redis dengan TTL.
func SetClientSession(ctx context.Context, key string, clientID string, ttl time.Duration) error {
	return rdb.Set(ctx, key, clientID, ttl).Err()
}

// GetSession mengambil value dari session key. Return error jika tidak ada atau expired.
func GetSession(ctx context.Context, key string) (string, error) {
	return rdb.Get(ctx, key).Result()
}

// DeleteSession menghapus session dari Redis (logout).
func DeleteSession(ctx context.Context, key string) {
	rdb.Del(ctx, key)
}

// ── Rate Limiter ────────────────────────────────────

// IncrementRateLimit menambah counter pesan sender dalam jendela waktu tertentu.
// Pertama kali dipanggil dalam window, otomatis set TTL = window duration.
// Return jumlah pesan sender dalam window saat ini.
func IncrementRateLimit(ctx context.Context, clientID string, sender string, window time.Duration) (int64, error) {
	key := fmt.Sprintf("ratelimit:%s:%s", clientID, sender)

	count, err := rdb.Incr(ctx, key).Result()
	if err != nil {
		return 0, err
	}

	// Set TTL hanya saat pertama kali (count == 1) supaya window tidak terus digeser
	if count == 1 {
		rdb.Expire(ctx, key, window)
	}

	return count, nil
}

// ── User Registration ───────────────────────────────

// RegisterUser menyimpan data registrasi user (nomor HP + password hash).
// clientID di-generate dari nomor HP: "client_<phone>".
func RegisterUser(ctx context.Context, phone string, passwordHash string) (string, error) {
	clientID := "client_" + phone

	// Cek apakah nomor sudah terdaftar
	exists, err := rdb.SIsMember(ctx, "clients", clientID).Result()
	if err != nil {
		return "", err
	}
	if exists {
		return "", fmt.Errorf("nomor %s sudah terdaftar", phone)
	}

	// Simpan password hash
	key := fmt.Sprintf("client:%s:password", clientID)
	if err := rdb.Set(ctx, key, passwordHash, 0).Err(); err != nil {
		return "", err
	}

	// Simpan nomor HP
	phoneKey := fmt.Sprintf("client:%s:phone", clientID)
	if err := rdb.Set(ctx, phoneKey, phone, 0).Err(); err != nil {
		return "", err
	}

	// Set plan default
	planKey := fmt.Sprintf("client:%s:plan", clientID)
	if err := rdb.Set(ctx, planKey, "basic", 0).Err(); err != nil {
		return "", err
	}

	return clientID, nil
}

// ActivateClient mendaftarkan clientID ke set "clients" setelah WA berhasil connect.
// Dipanggil setelah QR scan sukses — bukan saat registrasi.
func ActivateClient(ctx context.Context, clientID string) error {
	return rdb.SAdd(ctx, "clients", clientID).Err()
}

// IsRegistered cek apakah nomor HP sudah pernah daftar (belum tentu sudah aktif).
func IsRegistered(ctx context.Context, phone string) (bool, error) {
	clientID := "client_" + phone
	key := fmt.Sprintf("client:%s:phone", clientID)
	_, err := rdb.Get(ctx, key).Result()
	if err == redis.Nil {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return true, nil
}

// ── Subscription Lifecycle ──────────────────────────

const subscriptionDays = 30

// ActivateSubscription menyimpan tanggal aktivasi dan expired,
// serta menandai client sebagai aktif.
// Dipanggil saat admin konfirmasi pembayaran.
func ActivateSubscription(ctx context.Context, clientID string) error {
	now := time.Now()
	expiredAt := now.AddDate(0, 0, subscriptionDays)

	pipe := rdb.Pipeline()
	pipe.Set(ctx, fmt.Sprintf("client:%s:activated_at", clientID), now.Unix(), 0)
	pipe.Set(ctx, fmt.Sprintf("client:%s:expired_at", clientID), expiredAt.Unix(), 0)
	pipe.Set(ctx, fmt.Sprintf("client:%s:active", clientID), "1", 0)
	_, err := pipe.Exec(ctx)
	return err
}

// DeactivateClient menandai client sebagai tidak aktif (expired/belum bayar).
func DeactivateClient(ctx context.Context, clientID string) error {
	return rdb.Set(ctx, fmt.Sprintf("client:%s:active", clientID), "0", 0).Err()
}

// IsClientActive return true kalau client aktif dan belum expired.
func IsClientActive(ctx context.Context, clientID string) bool {
	val, err := rdb.Get(ctx, fmt.Sprintf("client:%s:active", clientID)).Result()
	if err != nil || val != "1" {
		return false
	}
	return true
}

// GetExpiredAt return waktu expired client. Return zero time kalau belum diset.
func GetExpiredAt(ctx context.Context, clientID string) time.Time {
	val, err := rdb.Get(ctx, fmt.Sprintf("client:%s:expired_at", clientID)).Result()
	if err != nil {
		return time.Time{}
	}
	ts, err := strconv.ParseInt(val, 10, 64)
	if err != nil {
		return time.Time{}
	}
	return time.Unix(ts, 0)
}

// GetActivatedAt return waktu aktivasi client.
func GetActivatedAt(ctx context.Context, clientID string) time.Time {
	val, err := rdb.Get(ctx, fmt.Sprintf("client:%s:activated_at", clientID)).Result()
	if err != nil {
		return time.Time{}
	}
	ts, err := strconv.ParseInt(val, 10, 64)
	if err != nil {
		return time.Time{}
	}
	return time.Unix(ts, 0)
}

// ShouldResetUsage return true kalau sudah masuk bulan baru sejak aktivasi.
// Contoh: aktivasi tanggal 15, maka reset terjadi setiap tanggal 15 bulan berikutnya.
func ShouldResetUsage(ctx context.Context, clientID string) bool {
	activatedAt := GetActivatedAt(ctx, clientID)
	if activatedAt.IsZero() {
		return false
	}

	now := time.Now()
	// Hari reset = hari aktivasi
	resetDay := activatedAt.Day()

	// Cek apakah hari ini adalah hari reset dan belum pernah reset bulan ini
	if now.Day() != resetDay {
		return false
	}

	// Cek last reset — supaya tidak reset dua kali di hari yang sama
	lastResetKey := fmt.Sprintf("client:%s:last_reset", clientID)
	lastReset, err := rdb.Get(ctx, lastResetKey).Result()
	if err == nil {
		// Sudah pernah reset — cek apakah reset-nya bulan ini
		ts, _ := strconv.ParseInt(lastReset, 10, 64)
		lastResetTime := time.Unix(ts, 0)
		if lastResetTime.Month() == now.Month() && lastResetTime.Year() == now.Year() {
			return false // sudah reset bulan ini
		}
	}

	return true
}

// MarkUsageReset mencatat waktu terakhir usage direset.
func MarkUsageReset(ctx context.Context, clientID string) error {
	key := fmt.Sprintf("client:%s:last_reset", clientID)
	return rdb.Set(ctx, key, time.Now().Unix(), 0).Err()
}

// ── WebSocket QR Token ──────────────────────────────

// SetWSToken menyimpan token sementara untuk autentikasi WebSocket QR.
// TTL 5 menit — cukup untuk user scan QR.
func SetWSToken(ctx context.Context, clientID string, token string) error {
	key := fmt.Sprintf("wstoken:%s", clientID)
	return rdb.Set(ctx, key, token, 5*time.Minute).Err()
}

// ValidateWSToken memvalidasi token WebSocket dan menghapusnya setelah dipakai.
// Return true kalau token valid, false kalau tidak ada atau salah.
func ValidateWSToken(ctx context.Context, clientID string, token string) bool {
	key := fmt.Sprintf("wstoken:%s", clientID)
	val, err := rdb.Get(ctx, key).Result()
	if err != nil || val != token {
		return false
	}
	// Hapus token setelah dipakai — one-time use
	rdb.Del(ctx, key)
	return true
}

// ── CRM Contact Tracking ────────────────────────────

// ContactInfo menyimpan info kontak yang pernah chat dengan bot.
type ContactInfo struct {
	JID        string    `json:"jid"`
	PushName   string    `json:"push_name"`
	LastSeen   time.Time `json:"last_seen"`
	TotalMsg   int64     `json:"total_msg"`
}

// TrackContact mencatat kontak yang chat dan update metadata-nya.
// Dipanggil setiap kali pesan masuk dari user.
func TrackContact(ctx context.Context, clientID string, jid string, pushName string) error {
	// Tambah ke set kontak client
	contactsKey := fmt.Sprintf("contacts:%s", clientID)
	rdb.SAdd(ctx, contactsKey, jid)

	// Simpan push_name (nama WA kontak)
	if pushName != "" {
		nameKey := fmt.Sprintf("contact:%s:%s:name", clientID, jid)
		rdb.Set(ctx, nameKey, pushName, 30*24*time.Hour)
	}

	// Update last seen
	lastSeenKey := fmt.Sprintf("contact:%s:%s:lastseen", clientID, jid)
	rdb.Set(ctx, lastSeenKey, time.Now().Unix(), 30*24*time.Hour)

	// Increment total pesan
	totalKey := fmt.Sprintf("contact:%s:%s:total", clientID, jid)
	rdb.Incr(ctx, totalKey)

	return nil
}

// ListContacts mengembalikan semua kontak yang pernah chat dengan client.
func ListContacts(ctx context.Context, clientID string) ([]ContactInfo, error) {
	contactsKey := fmt.Sprintf("contacts:%s", clientID)
	jids, err := rdb.SMembers(ctx, contactsKey).Result()
	if err != nil {
		return nil, err
	}

	var contacts []ContactInfo
	for _, jid := range jids {
		info := ContactInfo{JID: jid}

		// Ambil push_name
		nameKey := fmt.Sprintf("contact:%s:%s:name", clientID, jid)
		info.PushName, _ = rdb.Get(ctx, nameKey).Result()

		// Ambil last seen
		lastSeenKey := fmt.Sprintf("contact:%s:%s:lastseen", clientID, jid)
		if ts, err := rdb.Get(ctx, lastSeenKey).Result(); err == nil {
			if unix, err := strconv.ParseInt(ts, 10, 64); err == nil {
				info.LastSeen = time.Unix(unix, 0)
			}
		}

		// Ambil total pesan
		totalKey := fmt.Sprintf("contact:%s:%s:total", clientID, jid)
		if total, err := rdb.Get(ctx, totalKey).Result(); err == nil {
			info.TotalMsg, _ = strconv.ParseInt(total, 10, 64)
		}

		contacts = append(contacts, info)
	}

	// Sort by last seen terbaru
	for i := 0; i < len(contacts)-1; i++ {
		for j := i + 1; j < len(contacts); j++ {
			if contacts[j].LastSeen.After(contacts[i].LastSeen) {
				contacts[i], contacts[j] = contacts[j], contacts[i]
			}
		}
	}

	return contacts, nil
}

// GetFullHistory mengambil SEMUA history percakapan satu kontak (untuk CRM & export).
func GetFullHistory(ctx context.Context, clientID string, jid string) ([]ChatMessage, error) {
	key := fmt.Sprintf("history:%s:%s", clientID, jid)
	results, err := rdb.LRange(ctx, key, 0, -1).Result()
	if err != nil {
		return nil, err
	}

	var messages []ChatMessage
	for _, r := range results {
		var msg ChatMessage
		if err := json.Unmarshal([]byte(r), &msg); err != nil {
			continue
		}
		messages = append(messages, msg)
	}
	return messages, nil
}
