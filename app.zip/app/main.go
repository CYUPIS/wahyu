package main

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"syscall"

	"wa-ai/config"
	"wa-ai/cron"
	"wa-ai/logger"
	"wa-ai/queue"
	"wa-ai/store"
	"wa-ai/usage"
	"wa-ai/whatsapp"
	"wa-ai/worker"

	"go.uber.org/zap"
)

func main() {
	config.Load()
	logger.Init(config.C.AppEnv)
	defer logger.Sync()

	logger.Info("App started", zap.String("env", config.C.AppEnv))

	store.InitRedis(config.C.RedisAddr)
	queue.InitRedis(config.C.RedisAddr)
	usage.InitRedis(config.C.RedisAddr)
	logger.Info("Redis connected", zap.String("addr", config.C.RedisAddr))

	store.InitQdrant()
	worker.Init()
	logger.Info("Worker initialized")

	// ctx harus dideklarasikan sebelum dipakai
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// Start cron scheduler — cek expired & reset quota setiap jam
	cron.Start(ctx)

	clients, err := store.ListClients(ctx)
	if err != nil || len(clients) == 0 {
		logger.Warn("No clients found in Redis, starting with empty state")
		clients = []string{}
	}

	for _, clientID := range clients {
		sessionPath := fmt.Sprintf("%s/%s/wa.db", config.C.SessionDir, clientID)
		if _, err := os.Stat(sessionPath); os.IsNotExist(err) {
			logger.Warn("No WA session file found, skipping",
				zap.String("client", clientID),
			)
			continue
		}
		logger.Info("Reconnecting WA session", zap.String("client", clientID))
		go func(cid string) {
			if err := whatsapp.StartSessionBlocking(ctx, cid); err != nil {
				logger.Error("Failed to reconnect session",
					zap.String("client", cid),
					zap.Error(err),
				)
			}
		}(clientID)
	}

	go queue.Consume(ctx, worker.Handle)
	logger.Info("Consumer started")
	logger.Info("All systems ready")

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt, syscall.SIGTERM)
	<-quit

	logger.Info("Shutting down...")
	whatsapp.StopAll()
}
