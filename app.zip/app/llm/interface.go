package llm

import "context"

type LLM interface {
	Generate(ctx context.Context, prompt string) (string, error)
	GenerateWithSystem(ctx context.Context, systemPrompt string, userMessage string) (string, error)
	GenerateWithHistory(ctx context.Context, systemPrompt string, history []ChatMessage, userMessage string) (string, error)
}
