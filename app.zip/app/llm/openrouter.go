package llm

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"wa-ai/config"
	"wa-ai/logger"

	"go.uber.org/zap"
)

var httpClient = &http.Client{
	Timeout: 60 * time.Second,
}

type OpenRouter struct {
	apiKey string
	model  string
}

type ChatMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type chatRequest struct {
	Model    string        `json:"model"`
	Messages []ChatMessage `json:"messages"`
}

type chatResponse struct {
	Choices []struct {
		Message ChatMessage `json:"message"`
	} `json:"choices"`
	Error *struct {
		Message string `json:"message"`
	} `json:"error"`
}

func NewOpenRouter() *OpenRouter {
	return &OpenRouter{
		apiKey: config.C.OpenRouterKey,
		model:  config.C.LLMModel,
	}
}

func (o *OpenRouter) Generate(ctx context.Context, prompt string) (string, error) {
	return o.GenerateWithSystem(ctx, "", prompt)
}

func (o *OpenRouter) GenerateWithSystem(ctx context.Context, systemPrompt string, userMessage string) (string, error) {
	return o.GenerateWithHistory(ctx, systemPrompt, nil, userMessage)
}

func (o *OpenRouter) GenerateWithHistory(ctx context.Context, systemPrompt string, history []ChatMessage, userMessage string) (string, error) {
	messages := []ChatMessage{}

	if systemPrompt != "" {
		messages = append(messages, ChatMessage{
			Role:    "system",
			Content: systemPrompt,
		})
	}

	// Tambah history
	messages = append(messages, history...)

	// Tambah pesan user sekarang
	messages = append(messages, ChatMessage{
		Role:    "user",
		Content: userMessage,
	})

	reqBody := chatRequest{
		Model:    o.model,
		Messages: messages,
	}

	data, err := json.Marshal(reqBody)
	if err != nil {
		return "", err
	}

	req, err := http.NewRequestWithContext(ctx, "POST",
		"https://openrouter.ai/api/v1/chat/completions",
		bytes.NewBuffer(data),
	)
	if err != nil {
		return "", err
	}

	req.Header.Set("Authorization", "Bearer "+o.apiKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := httpClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("llm request failed: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	var result chatResponse
	if err := json.Unmarshal(body, &result); err != nil {
		return "", err
	}

	if result.Error != nil {
		logger.Error("OpenRouter error", zap.String("message", result.Error.Message))
		return "", fmt.Errorf("openrouter: %s", result.Error.Message)
	}

	if len(result.Choices) == 0 {
		return "", fmt.Errorf("openrouter: no choices returned")
	}

	return result.Choices[0].Message.Content, nil
}
