package queue

import (
	"context"
	"encoding/json"
	"time"

	"wa-ai/logger"

	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"
)

const StreamKey = "wa:messages"

type Message struct {
	Sender    string    `json:"sender"`
	Text      string    `json:"text"`
	ClientID  string    `json:"client_id"`
	Timestamp time.Time `json:"timestamp"`
}

var rdb *redis.Client

func InitRedis(addr string) {
	rdb = redis.NewClient(&redis.Options{
		Addr: addr,
	})
}

func Publish(ctx context.Context, msg Message) error {
	data, err := json.Marshal(msg)
	if err != nil {
		logger.Error("Failed to marshal message", zap.Error(err))
		return err
	}

	err = rdb.XAdd(ctx, &redis.XAddArgs{
		Stream: StreamKey,
		Values: map[string]interface{}{
			"payload": string(data),
		},
	}).Err()

	if err != nil {
		logger.Error("Failed to publish to Redis", zap.Error(err))
		return err
	}

	logger.Info("Message published to queue",
		zap.String("sender", msg.Sender),
		zap.String("text", msg.Text),
	)
	return nil
}
