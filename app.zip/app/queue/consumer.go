package queue

import (
	"context"
	"encoding/json"
	"time"

	"wa-ai/logger"

	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"
)

const (
	GroupName    = "chativa-workers"
	ConsumerName = "worker-1"
)

type HandlerFunc func(ctx context.Context, msg Message)

// initConsumerGroup membuat consumer group jika belum ada.
// "0" artinya group akan baca dari awal stream — tidak ada pesan yang terlewat.
func initConsumerGroup(ctx context.Context) {
	err := rdb.XGroupCreateMkStream(ctx, StreamKey, GroupName, "0").Err()
	if err != nil && err.Error() != "BUSYGROUP Consumer Group name already exists" {
		logger.Error("Failed to create consumer group", zap.Error(err))
	} else {
		logger.Info("Consumer group ready",
			zap.String("group", GroupName),
			zap.String("stream", StreamKey),
		)
	}
}

// reclaimPending mengambil pesan yang sudah di-deliver tapi belum di-ACK
// (misalnya karena bot crash sebelum selesai proses).
// Pesan yang pending lebih dari 30 detik akan di-reclaim dan diproses ulang.
func reclaimPending(ctx context.Context, handler HandlerFunc) {
	messages, _, err := rdb.XAutoClaim(ctx, &redis.XAutoClaimArgs{
		Stream:   StreamKey,
		Group:    GroupName,
		Consumer: ConsumerName,
		MinIdle:  30 * time.Second,
		Start:    "0-0",
		Count:    100,
	}).Result()

	if err != nil {
		if err != redis.Nil {
			logger.Error("Failed to reclaim pending messages", zap.Error(err))
		}
		return
	}

	if len(messages) > 0 {
		logger.Info("Reclaiming pending messages",
			zap.Int("count", len(messages)),
		)

		for _, msg := range messages {
			processMessage(ctx, msg, handler)
		}
	}
}

func processMessage(ctx context.Context, msg redis.XMessage, handler HandlerFunc) {
	payload, ok := msg.Values["payload"].(string)
	if !ok {
		// Pesan corrupt — ACK supaya tidak stuck di pending selamanya
		rdb.XAck(ctx, StreamKey, GroupName, msg.ID)
		return
	}

	var m Message
	if err := json.Unmarshal([]byte(payload), &m); err != nil {
		logger.Error("Failed to unmarshal message",
			zap.String("id", msg.ID),
			zap.Error(err),
		)
		// Corrupt — ACK dan skip
		rdb.XAck(ctx, StreamKey, GroupName, msg.ID)
		return
	}

	logger.Info("Message consumed from queue",
		zap.String("id", msg.ID),
		zap.String("sender", m.Sender),
		zap.String("text", m.Text),
	)

	// Proses pesan
	handler(ctx, m)

	// ACK setelah berhasil diproses — pesan tidak akan di-deliver ulang
	if err := rdb.XAck(ctx, StreamKey, GroupName, msg.ID).Err(); err != nil {
		logger.Error("Failed to ACK message",
			zap.String("id", msg.ID),
			zap.Error(err),
		)
	}
}

func Consume(ctx context.Context, handler HandlerFunc) {
	initConsumerGroup(ctx)

	// Reclaim pesan pending dari restart/crash sebelumnya
	reclaimPending(ctx, handler)

	logger.Info("Consumer started",
		zap.String("stream", StreamKey),
		zap.String("group", GroupName),
	)

	for {
		select {
		case <-ctx.Done():
			logger.Info("Consumer stopped")
			return
		default:
			// ">" artinya hanya baca pesan baru yang belum di-deliver ke group manapun
			results, err := rdb.XReadGroup(ctx, &redis.XReadGroupArgs{
				Group:    GroupName,
				Consumer: ConsumerName,
				Streams:  []string{StreamKey, ">"},
				Count:    10,
				Block:    5 * time.Second,
			}).Result()

			if err != nil {
				if err == context.Canceled {
					return
				}
				if err == redis.Nil {
					// Timeout normal — tidak ada pesan baru, lanjut loop
					continue
				}
				logger.Error("Failed to read from stream", zap.Error(err))
				continue
			}

			for _, stream := range results {
				for _, msg := range stream.Messages {
					processMessage(ctx, msg, handler)
				}
			}
		}
	}
}
