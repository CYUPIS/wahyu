package cron

import (
	"context"
	"time"

	"wa-ai/logger"
	"wa-ai/store"
	"wa-ai/usage"

	"go.uber.org/zap"
)

// Start menjalankan scheduler di background goroutine.
// Cek setiap jam — cukup untuk use case reset bulanan.
func Start(ctx context.Context) {
	go run(ctx)
	logger.Info("Cron scheduler started")
}

func run(ctx context.Context) {
	// Jalankan sekali saat startup, lalu setiap jam
	tick(ctx)

	ticker := time.NewTicker(1 * time.Hour)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			tick(ctx)
		case <-ctx.Done():
			logger.Info("Cron scheduler stopped")
			return
		}
	}
}

func tick(ctx context.Context) {
	clients, err := store.ListClients(ctx)
	if err != nil {
		logger.Error("Cron: failed to list clients", zap.Error(err))
		return
	}

	now := time.Now()

	for _, clientID := range clients {
		// ── Cek expired ────────────────────────────
		expiredAt := store.GetExpiredAt(ctx, clientID)

		if expiredAt.IsZero() {
			// Belum pernah diaktivasi — skip
			continue
		}

		if now.After(expiredAt) && store.IsClientActive(ctx, clientID) {
			// Expired — nonaktifkan
			if err := store.DeactivateClient(ctx, clientID); err != nil {
				logger.Error("Cron: failed to deactivate client",
					zap.String("client", clientID),
					zap.Error(err),
				)
			} else {
				logger.Info("Cron: client deactivated (expired)",
					zap.String("client", clientID),
					zap.Time("expired_at", expiredAt),
				)
			}
			continue
		}

		// ── Cek reset quota bulanan ─────────────────
		if store.IsClientActive(ctx, clientID) && store.ShouldResetUsage(ctx, clientID) {
			if err := usage.Reset(ctx, clientID); err != nil {
				logger.Error("Cron: failed to reset usage",
					zap.String("client", clientID),
					zap.Error(err),
				)
				continue
			}

			if err := store.MarkUsageReset(ctx, clientID); err != nil {
				logger.Error("Cron: failed to mark usage reset",
					zap.String("client", clientID),
					zap.Error(err),
				)
				continue
			}

			logger.Info("Cron: usage reset for client",
				zap.String("client", clientID),
				zap.Time("next_reset", store.GetExpiredAt(ctx, clientID)),
			)
		}
	}
}
