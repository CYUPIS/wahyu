package guardrail

import (
	"strings"
)

type Result struct {
	Allowed bool
	Reason  string
}

// Kata-kata yang diblokir
var blockedKeywords = []string{
	"anjing", "babi", "bangsat", "kontol", "memek",
	"fuck", "shit", "asshole", "spam", "promo gratis",
}

// Maksimal panjang pesan
const maxMessageLength = 1000

func Check(text string) Result {
	// Cek panjang pesan
	if len(text) > maxMessageLength {
		return Result{
			Allowed: false,
			Reason:  "pesan terlalu panjang",
		}
	}

	// Cek pesan kosong
	if strings.TrimSpace(text) == "" {
		return Result{
			Allowed: false,
			Reason:  "pesan kosong",
		}
	}

	// Cek kata terlarang
	lower := strings.ToLower(text)
	for _, keyword := range blockedKeywords {
		if strings.Contains(lower, keyword) {
			return Result{
				Allowed: false,
				Reason:  "pesan mengandung kata terlarang",
			}
		}
	}

	return Result{Allowed: true}
}
