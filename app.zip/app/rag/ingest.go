package rag

import (
	"context"
	"crypto/md5"
	"fmt"
	"time"

	"wa-ai/logger"
	"wa-ai/store"

	"go.uber.org/zap"
)

func Ingest(ctx context.Context, clientID string, text string, filename string) error {
	collection := "client_" + clientID

	err := store.Qdrant.CreateCollection(ctx, collection, 768)
	if err != nil {
		return err
	}

	chunks := Chunk(text)
	logger.Info("Document chunked",
		zap.String("client", clientID),
		zap.Int("chunks", len(chunks)),
	)

	// Generate doc ID unik per file
	docID := fmt.Sprintf("%x", md5.Sum([]byte(clientID+filename+time.Now().String())))

	var points []store.Point
	for i, chunk := range chunks {
		vector, err := Embed(ctx, chunk)
		if err != nil {
			logger.Error("Failed to embed chunk",
				zap.Int("chunk", i),
				zap.Error(err),
			)
			continue
		}

		pointID := fmt.Sprintf("%x", md5.Sum([]byte(clientID+chunk+docID)))

		points = append(points, store.Point{
			ID:     pointID,
			Vector: vector,
			Payload: map[string]interface{}{
				"text":      chunk,
				"client_id": clientID,
				"doc_id":    docID,
				"filename":  filename,
			},
		})
	}

	if len(points) == 0 {
		return fmt.Errorf("no points to upsert")
	}

	if err := store.Qdrant.Upsert(ctx, collection, points); err != nil {
		return err
	}

	// Track dokumen di Redis
	doc := store.Document{
		ID:        docID,
		Filename:  filename,
		Chunks:    len(points),
		CreatedAt: time.Now(),
	}
	store.AddDocument(ctx, clientID, doc)

	return nil
}

func IngestDocument(ctx context.Context, clientID string, text string) error {
	return Ingest(ctx, clientID, text, "document")
}

func IngestDocumentWithName(ctx context.Context, clientID string, text string, filename string) error {
	return Ingest(ctx, clientID, text, filename)
}
