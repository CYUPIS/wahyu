package rag

import (
	"context"
	"fmt"
)

const TopK = 3

func Search(ctx context.Context, clientID string, query string) (string, error) {
	contextText, err := Retrieve(ctx, clientID, query, TopK)
	if err != nil {
		return "", fmt.Errorf("retrieval failed: %w", err)
	}
	return contextText, nil
}
