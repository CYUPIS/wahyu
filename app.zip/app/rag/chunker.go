package rag

import "strings"

const (
	ChunkSize    = 500 // karakter per chunk (rune-safe)
	ChunkOverlap = 50  // overlap antar chunk
)

// Chunk memecah teks menjadi potongan-potongan dengan ukuran ChunkSize.
// Menggunakan []rune agar aman untuk teks multibyte (Indonesia, Arab, Chinese, dll).
// Pemotongan selalu di batas kata (spasi/newline) supaya chunk tidak terpotong di tengah kata.
func Chunk(text string) []string {
	text = strings.TrimSpace(text)

	// Konversi ke rune supaya len() dan slice aman untuk Unicode
	runes := []rune(text)

	if len(runes) <= ChunkSize {
		return []string{text}
	}

	var chunks []string
	start := 0

	for start < len(runes) {
		end := start + ChunkSize
		if end > len(runes) {
			end = len(runes)
		}

		// Cari batas kata terdekat (mundur dari end)
		if end < len(runes) {
			originalEnd := end
			for end > start && runes[end] != ' ' && runes[end] != '\n' {
				end--
			}
			// Kalau tidak ketemu spasi (kata terlalu panjang), paksa pakai originalEnd
			if end <= start {
				end = originalEnd
			}
		}

		chunk := strings.TrimSpace(string(runes[start:end]))
		if chunk != "" {
			chunks = append(chunks, chunk)
		}

		// Maju dengan overlap, pastikan selalu ada progres ke depan
		nextStart := end - ChunkOverlap
		if nextStart <= start {
			start = end
		} else {
			start = nextStart
		}
	}

	return chunks
}
