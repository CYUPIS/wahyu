package rag

import (
	"context"
	"fmt"
	"strings"

	"wa-ai/store"
)

func Retrieve(ctx context.Context, clientID string, query string, topK int) (string, error) {
	collection := "client_" + clientID

	// Embed query
	vector, err := Embed(ctx, query)
	if err != nil {
		return "", err
	}

	// Search Qdrant
	results, err := store.Qdrant.Search(ctx, collection, vector, topK)
	if err != nil {
		return "", err
	}

	if len(results) == 0 {
		return "", fmt.Errorf("no results found")
	}

	// Gabung hasil jadi context string
	var parts []string
	for _, r := range results {
		if text, ok := r.Payload["text"].(string); ok {
			parts = append(parts, text)
		}
	}

	return strings.Join(parts, "\n\n"), nil
}
