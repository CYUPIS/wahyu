module wa-ai

go 1.25.0

require (
	github.com/coder/websocket v1.8.14
	github.com/gorilla/mux v1.8.1
	github.com/joho/godotenv v1.5.1
	github.com/ledongthuc/pdf v0.0.0-20250511090121-5959a4027728
	github.com/mattn/go-sqlite3 v1.14.44
	github.com/redis/go-redis/v9 v9.19.0
	go.mau.fi/whatsmeow v0.0.0-20260427122815-7514259253a7
	go.uber.org/zap v1.28.0
	golang.org/x/crypto v0.50.0
	google.golang.org/protobuf v1.36.11
)

require (
	filippo.io/edwards25519 v1.1.0 // indirect
	github.com/beeper/argo-go v1.1.2 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/elliotchance/orderedmap/v3 v3.1.0 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/mattn/go-colorable v0.1.14 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/petermattis/goid v0.0.0-20260330135022-df67b199bc81 // indirect
	github.com/rs/zerolog v1.35.0 // indirect
	github.com/vektah/gqlparser/v2 v2.5.27 // indirect
	go.mau.fi/libsignal v0.2.1 // indirect
	go.mau.fi/util v0.9.8 // indirect
	go.uber.org/atomic v1.11.0 // indirect
	go.uber.org/multierr v1.10.0 // indirect
	golang.org/x/exp v0.0.0-20260410095643-746e56fc9e2f // indirect
	golang.org/x/net v0.53.0 // indirect
	golang.org/x/sync v0.20.0 // indirect
	golang.org/x/sys v0.43.0 // indirect
	golang.org/x/text v0.36.0 // indirect
)
