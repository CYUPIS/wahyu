package dashboard

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"crypto/rand"
	"encoding/hex"

	"wa-ai/dashboard/auth"
	"wa-ai/logger"
	"wa-ai/rag"
	"wa-ai/store"
	"wa-ai/usage"
	"wa-ai/whatsapp"

	"regexp"

	"github.com/coder/websocket"
	"github.com/gorilla/mux"
	"github.com/ledongthuc/pdf"
	"go.uber.org/zap"
	"golang.org/x/crypto/bcrypt"
)

// wsAcceptOptions konfigurasi WebSocket — InsecureSkipVerify untuk development.
// Di production bisa di-restrict ke domain tertentu via OriginPatterns.
var wsAcceptOptions = &websocket.AcceptOptions{
	// Di production (APP_ENV != development), validasi origin diaktifkan
	InsecureSkipVerify: os.Getenv("APP_ENV") == "development",
}

// ── Pages ──────────────────────────────────────────

func handleIndex(w http.ResponseWriter, r *http.Request) {
	t := tmpl("index")
	t.Execute(w, nil)
}

func handleClientDetail(w http.ResponseWriter, r *http.Request) {
	t := tmpl("client")
	vars := mux.Vars(r)
	t.Execute(w, map[string]string{"ClientID": vars["id"]})
}

// ── API ────────────────────────────────────────────

type ClientInfo struct {
	ID           string `json:"id"`
	Plan         string `json:"plan"`
	Usage        int64  `json:"usage"`
	Quota        int64  `json:"quota"`
	DocCount     int64  `json:"doc_count"`
	MaxDocs      int    `json:"max_docs"`
	SystemPrompt string `json:"system_prompt"`

	Active    bool      `json:"active"`
	ExpiredAt time.Time `json:"expired_at"`
}

func jsonResponse(w http.ResponseWriter, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(data)
}

func jsonError(w http.ResponseWriter, msg string, code int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]string{"error": msg})
}

func apiListClients(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()

	keys, err := store.ListClients(ctx)
	if err != nil {
		jsonError(w, "Failed to list clients", 500)
		return
	}

	var clients []ClientInfo
	for _, clientID := range keys {
		info, err := buildClientInfo(ctx, clientID)
		if err != nil {
			logger.Warn("Failed to build client info, skipping",
				zap.String("client", clientID),
				zap.Error(err),
			)
			continue
		}
		clients = append(clients, info)
	}

	if clients == nil {
		clients = []ClientInfo{}
	}

	jsonResponse(w, clients)
}

func apiGetClient(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	vars := mux.Vars(r)
	clientID := vars["id"]

	info, err := buildClientInfo(ctx, clientID)
	if err != nil {
		jsonError(w, "Failed to get client", 500)
		return
	}

	jsonResponse(w, info)
}

func apiCreateClient(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()

	var body struct {
		ID   string `json:"id"`
		Plan string `json:"plan"`
	}
	json.NewDecoder(r.Body).Decode(&body)

	if body.ID == "" {
		jsonError(w, "Client ID required", 400)
		return
	}

	plan := body.Plan
	if plan == "" {
		plan = "basic"
	}

	if err := store.RegisterClient(ctx, body.ID); err != nil {
		jsonError(w, "Failed to register client", 500)
		return
	}

	if err := store.SetPlan(ctx, body.ID, plan); err != nil {
		jsonError(w, "Failed to set plan", 500)
		return
	}

	jsonResponse(w, map[string]string{
		"status": "created",
		"id":     body.ID,
		"plan":   plan,
	})
}

func apiSetPrompt(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	vars := mux.Vars(r)
	clientID := vars["id"]

	var body struct {
		Prompt string `json:"prompt"`
	}
	json.NewDecoder(r.Body).Decode(&body)

	if err := store.SetSystemPrompt(ctx, clientID, body.Prompt); err != nil {
		jsonError(w, "Failed to set prompt", 500)
		return
	}

	jsonResponse(w, map[string]string{"status": "ok"})
}

func apiSetQuota(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	vars := mux.Vars(r)
	clientID := vars["id"]

	var body struct {
		Quota int64 `json:"quota"`
	}
	json.NewDecoder(r.Body).Decode(&body)

	if err := usage.SetQuota(ctx, clientID, body.Quota); err != nil {
		jsonError(w, "Failed to set quota", 500)
		return
	}

	jsonResponse(w, map[string]string{"status": "ok"})
}

func apiSetPlan(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	vars := mux.Vars(r)
	clientID := vars["id"]

	var body struct {
		Plan string `json:"plan"`
	}
	json.NewDecoder(r.Body).Decode(&body)

	if err := store.SetPlan(ctx, clientID, body.Plan); err != nil {
		jsonError(w, "Failed to set plan", 500)
		return
	}

	// Sync quota otomatis sesuai plan baru
	// Hapus custom quota supaya fallback ke plan.MaxMessages
	plan := store.GetPlan(ctx, clientID)
	if err := usage.SetQuota(ctx, clientID, int64(plan.MaxMessages)); err != nil {
		logger.Warn("Failed to sync quota after plan change",
			zap.String("client", clientID),
			zap.Error(err),
		)
	} else {
		logger.Info("Quota synced after plan change",
			zap.String("client", clientID),
			zap.Int("quota", plan.MaxMessages),
		)
	}

	jsonResponse(w, map[string]string{"status": "ok"})
}

func apiGetUsage(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	vars := mux.Vars(r)
	clientID := vars["id"]

	count, err := usage.GetUsage(ctx, clientID)
	if err != nil {
		jsonError(w, "Failed to get usage", 500)
		return
	}

	quota, err := usage.GetQuota(ctx, clientID)
	if err != nil {
		jsonError(w, "Failed to get quota", 500)
		return
	}

	// Guard divide by zero — quota 0 bisa terjadi kalau Redis kosong
	var percent float64
	if quota > 0 {
		percent = float64(count) / float64(quota) * 100
	}

	jsonResponse(w, map[string]interface{}{
		"usage":   count,
		"quota":   quota,
		"percent": fmt.Sprintf("%.1f%%", percent),
	})
}

func apiResetUsage(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	vars := mux.Vars(r)
	clientID := vars["id"]

	if err := usage.Reset(ctx, clientID); err != nil {
		jsonError(w, "Failed to reset usage", 500)
		return
	}

	jsonResponse(w, map[string]string{"status": "ok"})
}

// ── Helper ─────────────────────────────────────────

func buildClientInfo(ctx context.Context, clientID string) (ClientInfo, error) {
	plan := store.GetPlan(ctx, clientID)

	usageCount, err := usage.GetUsage(ctx, clientID)
	if err != nil {
		logger.Error("buildClientInfo: failed to get usage",
			zap.String("client", clientID), zap.Error(err))
		return ClientInfo{}, err
	}

	quota, err := usage.GetQuota(ctx, clientID)
	if err != nil {
		logger.Error("buildClientInfo: failed to get quota",
			zap.String("client", clientID), zap.Error(err))
		return ClientInfo{}, err
	}

	docCount, err := store.GetDocCount(ctx, clientID)
	if err != nil {
		logger.Error("buildClientInfo: failed to get doc count",
			zap.String("client", clientID), zap.Error(err))
		return ClientInfo{}, err
	}

	prompt, err := store.GetSystemPrompt(ctx, clientID)
	if err != nil {
		logger.Error("buildClientInfo: failed to get system prompt",
			zap.String("client", clientID), zap.Error(err))
		return ClientInfo{}, err
	}

	// Ambil nama plan key
	planName := "basic"
	for k, p := range store.Plans {
		if p.Name == plan.Name {
			planName = k
			break
		}
	}

	return ClientInfo{
		ID:           clientID,
		Plan:         planName,
		Usage:        usageCount,
		Quota:        quota,
		DocCount:     docCount,
		MaxDocs:      plan.MaxDocs,
		SystemPrompt: prompt,

		Active:    store.IsClientActive(ctx, clientID),
		ExpiredAt: store.GetExpiredAt(ctx, clientID),
	}, nil

}

// ── Upload Document ─────────────────────────────────

// allowedMIME mendefinisikan MIME type yang valid per ekstensi file.
// Ini mencegah user upload file berbahaya dengan rename ekstensi.
var allowedMIME = map[string]string{
	".txt": "text/plain",
	".pdf": "application/pdf",
}

func apiUploadDoc(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	vars := mux.Vars(r)
	clientID := vars["id"]

	// Cek doc limit
	allowed, err := store.IsDocAllowed(ctx, clientID)
	if err != nil {
		jsonError(w, "Failed to check doc limit", 500)
		return
	}
	if !allowed {
		plan := store.GetPlan(ctx, clientID)
		jsonError(w, fmt.Sprintf("Batas dokumen tercapai (max %d untuk paket %s)", plan.MaxDocs, plan.Name), 400)
		return
	}

	// Parse multipart form — max 10MB
	r.ParseMultipartForm(10 << 20)

	file, header, err := r.FormFile("document")
	if err != nil {
		jsonError(w, "File tidak ditemukan", 400)
		return
	}
	defer file.Close()

	ext := strings.ToLower(filepath.Ext(header.Filename))

	// Validasi ekstensi dulu
	if _, ok := allowedMIME[ext]; !ok {
		jsonError(w, "Format tidak didukung. Gunakan .txt atau .pdf", 400)
		return
	}

	// Baca 512 byte pertama untuk deteksi MIME type sebenarnya
	header512 := make([]byte, 512)
	n, err := file.Read(header512)
	if err != nil && err != io.EOF {
		jsonError(w, "Gagal membaca file", 500)
		return
	}
	header512 = header512[:n]

	detectedMIME := http.DetectContentType(header512)

	// Validasi MIME type cocok dengan ekstensi
	// DetectContentType untuk PDF return "application/pdf"
	// Untuk txt bisa return "text/plain; charset=utf-8" jadi kita pakai HasPrefix
	expectedMIME := allowedMIME[ext]
	if !strings.HasPrefix(detectedMIME, expectedMIME) {
		logger.Warn("MIME type mismatch on upload",
			zap.String("client", clientID),
			zap.String("filename", header.Filename),
			zap.String("detected", detectedMIME),
			zap.String("expected", expectedMIME),
		)
		jsonError(w, "Isi file tidak sesuai dengan ekstensi", 400)
		return
	}

	// Gabungkan kembali 512 byte yang sudah dibaca dengan sisa file
	fullData := bytes.NewReader(append(header512, func() []byte {
		rest, _ := io.ReadAll(file)
		return rest
	}()...))

	// Baca konten sesuai tipe
	var text string

	switch ext {
	case ".txt":
		data, err := io.ReadAll(fullData)
		if err != nil {
			jsonError(w, "Gagal membaca file", 500)
			return
		}
		text = string(data)

	case ".pdf":
		// PDF library butuh file path, simpan ke temp file dulu
		tmp, err := os.CreateTemp("", "upload-*.pdf")
		if err != nil {
			jsonError(w, "Gagal membuat temp file", 500)
			return
		}
		defer os.Remove(tmp.Name())

		io.Copy(tmp, fullData)
		tmp.Close()

		text, err = extractPDF(tmp.Name())
		if err != nil {
			jsonError(w, "Gagal membaca PDF: "+err.Error(), 500)
			return
		}
	}

	if strings.TrimSpace(text) == "" {
		jsonError(w, "Dokumen kosong", 400)
		return
	}

	// Ingest ke Qdrant
	if err := rag.IngestDocumentWithName(ctx, clientID, text, header.Filename); err != nil {
		jsonError(w, "Gagal ingest dokumen: "+err.Error(), 500)
		return
	}

	// Increment doc count
	count, _ := store.IncrementDocCount(ctx, clientID)

	jsonResponse(w, map[string]interface{}{
		"status":    "ok",
		"filename":  header.Filename,
		"doc_count": count,
	})
}

func extractPDF(path string) (string, error) {
	f, r, err := pdf.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()

	var buf strings.Builder
	for i := 1; i <= r.NumPage(); i++ {
		page := r.Page(i)
		if page.V.IsNull() {
			continue
		}
		content, err := page.GetPlainText(nil)
		if err != nil {
			continue
		}
		buf.WriteString(content)
		buf.WriteString("\n")
	}

	return buf.String(), nil
}

// ── Auth ───────────────────────────────────────────

func handleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		setCSRFCookie(w, r)
		t := tmpl("login")
		t.Execute(w, nil)
		return
	}

	username := r.FormValue("username")
	password := r.FormValue("password")

	token, ok := auth.Login(username, password)
	if !ok {
		t := tmpl("login")
		t.Execute(w, map[string]string{"Error": "Username atau password salah!"})
		return
	}

	auth.SetCookie(w, token)
	http.Redirect(w, r, "/", http.StatusFound)
}

func handleLogout(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("session")
	if err == nil {
		auth.Logout(cookie.Value)
	}
	auth.ClearCookie(w)
	http.Redirect(w, r, "/login", http.StatusFound)
}

// ── Document Management ────────────────────────────

func apiListDocs(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	vars := mux.Vars(r)
	clientID := vars["id"]

	docs, err := store.ListDocuments(ctx, clientID)
	if err != nil {
		jsonError(w, "Failed to list documents", 500)
		return
	}

	if docs == nil {
		docs = []store.Document{}
	}

	jsonResponse(w, docs)
}

func apiDeleteDoc(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	vars := mux.Vars(r)
	clientID := vars["id"]
	docID := vars["doc_id"]

	collection := "client_" + clientID

	if err := store.Qdrant.DeleteByDocID(ctx, collection, docID); err != nil {
		jsonError(w, "Failed to delete from Qdrant", 500)
		return
	}

	if err := store.DeleteDocument(ctx, clientID, docID); err != nil {
		jsonError(w, "Failed to delete document record", 500)
		return
	}

	store.DecrementDocCount(ctx, clientID)

	jsonResponse(w, map[string]string{"status": "deleted"})
}

// ── Portal Client ──────────────────────────────────

func handlePortalLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		setCSRFCookie(w, r)
		t := tmpl("portal_login")
		t.Execute(w, nil)
		return
	}

	clientID := r.FormValue("client_id")
	password := r.FormValue("password")

	token, ok := auth.ClientLogin(clientID, password)
	if !ok {
		t := tmpl("portal_login")
		t.Execute(w, map[string]string{"Error": "Client ID atau password salah!"})
		return
	}

	auth.SetClientCookie(w, token)
	http.Redirect(w, r, "/portal", http.StatusFound)
}

func handlePortalLogout(w http.ResponseWriter, r *http.Request) {
	auth.ClearClientCookie(w)
	http.Redirect(w, r, "/portal/login", http.StatusFound)
}

func handlePortalDashboard(w http.ResponseWriter, r *http.Request) {
	t := tmpl("portal_dashboard")
	t.Execute(w, nil)
}

func portalApiInfo(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	clientID, _ := auth.IsClientAuthenticated(r)

	info, err := buildClientInfo(ctx, clientID)
	if err != nil {
		jsonError(w, "Failed to get info", 500)
		return
	}

	jsonResponse(w, info)
}

func portalApiDocs(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	clientID, _ := auth.IsClientAuthenticated(r)

	docs, err := store.ListDocuments(ctx, clientID)
	if err != nil {
		jsonError(w, "Failed to list docs", 500)
		return
	}

	if docs == nil {
		docs = []store.Document{}
	}

	jsonResponse(w, docs)
}

func apiSetClientPassword(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	vars := mux.Vars(r)
	clientID := vars["id"]

	var body struct {
		Password string `json:"password"`
	}
	json.NewDecoder(r.Body).Decode(&body)

	if body.Password == "" {
		jsonError(w, "Password tidak boleh kosong", 400)
		return
	}

	if err := store.SetClientPassword(ctx, clientID, body.Password); err != nil {
		jsonError(w, "Failed to set password", 500)
		return
	}

	jsonResponse(w, map[string]string{"status": "ok"})
}

// ── Registration & QR WebSocket ────────────────────

// handleRegister melayani halaman registrasi user baru.
func handleRegister(w http.ResponseWriter, r *http.Request) {
	t := tmpl("register")
	t.Execute(w, nil)
}

// apiRegister memproses form registrasi:
// 1. Validasi input
// 2. Hash password
// 3. Simpan ke Redis (belum aktif)
// 4. Return clientID untuk dipakai di WebSocket QR
func apiRegister(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Phone    string `json:"phone"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		jsonError(w, "Request tidak valid", 400)
		return
	}

	if body.Phone == "" || body.Password == "" {
		jsonError(w, "Nomor HP dan password wajib diisi", 400)
		return
	}

	if len(body.Password) < 8 {
		jsonError(w, "Password minimal 8 karakter", 400)
		return
	}

	// Validasi format nomor HP — harus 628xxxxxxxx (10-15 digit)
	phoneRegex := regexp.MustCompile(`^62\d{8,13}$`)
	if !phoneRegex.MatchString(body.Phone) {
		jsonError(w, "Format nomor tidak valid. Gunakan format 628xxxxxxxx", 400)
		return
	}

	ctx := context.Background()

	// Cek apakah nomor sudah terdaftar
	registered, err := store.IsRegistered(ctx, body.Phone)
	if err != nil {
		jsonError(w, "Terjadi kesalahan, coba lagi", 500)
		return
	}
	if registered {
		jsonError(w, "Nomor HP sudah terdaftar", 400)
		return
	}

	// Hash password
	hash, err := bcrypt.GenerateFromPassword([]byte(body.Password), bcrypt.DefaultCost)
	if err != nil {
		jsonError(w, "Terjadi kesalahan, coba lagi", 500)
		return
	}

	// Simpan user (belum aktif, belum masuk set "clients")
	clientID, err := store.RegisterUser(ctx, body.Phone, string(hash))
	if err != nil {
		jsonError(w, err.Error(), 400)
		return
	}

	// Generate token sementara untuk autentikasi WebSocket
	tokenBytes := make([]byte, 16)
	rand.Read(tokenBytes)
	wsToken := hex.EncodeToString(tokenBytes)

	ctx2 := context.Background()
	if err := store.SetWSToken(ctx2, clientID, wsToken); err != nil {
		logger.Error("Failed to set WS token", zap.Error(err))
		jsonError(w, "Terjadi kesalahan, coba lagi", 500)
		return
	}

	logger.Info("User registered", zap.String("client", clientID))

	jsonResponse(w, map[string]string{
		"client_id": clientID,
		"ws_token":  wsToken,
		"status":    "registered",
	})
}

// handleQRWebSocket membuka koneksi WebSocket dan stream QR events ke browser.
// Flow:
//  1. Browser connect ke /ws/qr/{clientID}
//  2. Server panggil whatsapp.StartSession() — non-blocking
//  3. QR events di-forward ke browser via WebSocket
//  4. Saat "connected" — client diaktifkan di Redis
func handleQRWebSocket(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	clientID := vars["client_id"]
	token := r.URL.Query().Get("token")

	// Validasi token sebelum upgrade ke WebSocket
	if !store.ValidateWSToken(context.Background(), clientID, token) {
		logger.Warn("WebSocket auth failed",
			zap.String("client", clientID),
		)
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	// Upgrade ke WebSocket
	conn, err := websocket.Accept(w, r, wsAcceptOptions)
	if err != nil {
		logger.Error("WebSocket upgrade failed", zap.Error(err))
		return
	}
	defer conn.CloseNow()

	ctx := r.Context()

	// Channel untuk terima QR events dari whatsapp package
	qrChan := make(chan whatsapp.QREvent, 5)

	// Start session — non-blocking, QR events masuk ke qrChan
	whatsapp.StartSession(ctx, clientID, qrChan)

	// Forward semua events ke browser
	for evt := range qrChan {
		msg, _ := json.Marshal(evt)
		if err := conn.Write(ctx, websocket.MessageText, msg); err != nil {
			logger.Warn("WebSocket write failed", zap.Error(err))
			return
		}

		// Kalau sudah connected, aktifkan client di Redis
		if evt.Type == "connected" {
			if err := store.ActivateClient(context.Background(), clientID); err != nil {
				logger.Error("Failed to activate client",
					zap.String("client", clientID),
					zap.Error(err),
				)
			} else {
				logger.Info("Client activated", zap.String("client", clientID))
			}
			return
		}

		// Kalau error, tutup koneksi
		if evt.Type == "error" {
			return
		}
	}
}

// ── Subscription Management (Admin) ────────────────

// apiActivateSubscription dipanggil admin setelah client bayar.
// Menyimpan activated_at, expired_at, dan set active = 1.
func apiActivateSubscription(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	vars := mux.Vars(r)
	clientID := vars["id"]

	if err := store.ActivateSubscription(ctx, clientID); err != nil {
		jsonError(w, "Failed to activate subscription", 500)
		return
	}

	expiredAt := store.GetExpiredAt(ctx, clientID)
	logger.Info("Subscription activated",
		zap.String("client", clientID),
		zap.Time("expired_at", expiredAt),
	)

	jsonResponse(w, map[string]interface{}{
		"status":     "activated",
		"expired_at": expiredAt.Format("2006-01-02"),
	})
}

// apiDeactivateSubscription dipanggil admin untuk nonaktifkan client manual.
func apiDeactivateSubscription(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	vars := mux.Vars(r)
	clientID := vars["id"]

	if err := store.DeactivateClient(ctx, clientID); err != nil {
		jsonError(w, "Failed to deactivate client", 500)
		return
	}

	logger.Info("Client deactivated manually", zap.String("client", clientID))
	jsonResponse(w, map[string]string{"status": "deactivated"})
}

// ── Portal CRM ─────────────────────────────────────

// portalApiContacts mengembalikan daftar kontak yang pernah chat dengan bot client.
func portalApiContacts(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	clientID, _ := auth.IsClientAuthenticated(r)

	contacts, err := store.ListContacts(ctx, clientID)
	if err != nil {
		jsonError(w, "Failed to list contacts", 500)
		return
	}

	if contacts == nil {
		contacts = []store.ContactInfo{}
	}

	jsonResponse(w, contacts)
}

// portalApiHistory mengembalikan full history percakapan satu kontak.
func portalApiHistory(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	clientID, _ := auth.IsClientAuthenticated(r)
	vars := mux.Vars(r)
	jid := vars["jid"]

	messages, err := store.GetFullHistory(ctx, clientID, jid)
	if err != nil {
		jsonError(w, "Failed to get history", 500)
		return
	}

	if messages == nil {
		messages = []store.ChatMessage{}
	}

	jsonResponse(w, messages)
}

// portalApiExportHistory export history percakapan ke file .txt
func portalApiExportHistory(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	clientID, _ := auth.IsClientAuthenticated(r)
	vars := mux.Vars(r)
	jid := vars["jid"]

	messages, err := store.GetFullHistory(ctx, clientID, jid)
	if err != nil {
		jsonError(w, "Failed to get history", 500)
		return
	}

	// Build raw text
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Export Percakapan\nKontak: %s\nClient: %s\n", jid, clientID))
	sb.WriteString("========================================\n\n")

	for _, msg := range messages {
		role := "User"
		if msg.Role == "assistant" {
			role = "Bot"
		}
		sb.WriteString(fmt.Sprintf("[%s] %s:\n%s\n\n",
			msg.Timestamp.Format("2006-01-02 15:04:05"),
			role,
			msg.Content,
		))
	}

	// Set header untuk download file
	filename := fmt.Sprintf("chat_%s_%s.txt",
		strings.ReplaceAll(jid, ":", "_"),
		time.Now().Format("20060102"),
	)
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, filename))
	w.Write([]byte(sb.String()))
}
