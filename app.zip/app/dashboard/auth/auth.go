package auth

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"net/http"
	"os"
	"time"

	"wa-ai/logger"
	"wa-ai/store"

	"golang.org/x/crypto/bcrypt"

	"go.uber.org/zap"
)

// ── Helpers ────────────────────────────────────────

func generateToken() string {
	b := make([]byte, 32)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func getAdminUsername() string {
	u := os.Getenv("ADMIN_USERNAME")
	if u == "" {
		return "admin"
	}
	return u
}

// checkAdminPassword membandingkan input dengan bcrypt hash dari ADMIN_PASSWORD_HASH.
// Kalau env belum di-set, app langsung fatal supaya tidak jalan dengan password kosong.
func checkAdminPassword(input string) bool {
	hash := os.Getenv("ADMIN_PASSWORD_HASH")
	if hash == "" {
		logger.Fatal("ADMIN_PASSWORD_HASH environment variable is not set. " +
			"Generate with: go run cmd/genpwd/main.go <password>")
	}
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(input))
	return err == nil
}

// ── Admin Session (Redis-backed) ───────────────────

const adminSessionTTL = 24 * time.Hour

func adminSessionKey(token string) string {
	return fmt.Sprintf("session:admin:%s", token)
}

func Login(username, password string) (string, bool) {
	if username != getAdminUsername() || !checkAdminPassword(password) {
		return "", false
	}

	token := generateToken()
	ctx := context.Background()
	err := store.SetAdminSession(ctx, adminSessionKey(token), username, adminSessionTTL)
	if err != nil {
		logger.Error("Failed to store admin session", zap.Error(err))
		return "", false
	}

	return token, true
}

func Logout(token string) {
	ctx := context.Background()
	store.DeleteSession(ctx, adminSessionKey(token))
}

func IsAuthenticated(r *http.Request) bool {
	cookie, err := r.Cookie("session")
	if err != nil {
		return false
	}

	ctx := context.Background()
	_, err = store.GetSession(ctx, adminSessionKey(cookie.Value))
	return err == nil
}

func SetCookie(w http.ResponseWriter, token string) {
	http.SetCookie(w, &http.Cookie{
		Name:     "session",
		Value:    token,
		Path:     "/",
		HttpOnly: true,
		Secure:   true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   86400,
	})
}

func ClearCookie(w http.ResponseWriter) {
	http.SetCookie(w, &http.Cookie{
		Name:     "session",
		Value:    "",
		Path:     "/",
		HttpOnly: true,
		Secure:   true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   -1,
	})
}

func Middleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !IsAuthenticated(r) {
			http.Redirect(w, r, "/login", http.StatusFound)
			return
		}
		next(w, r)
	}
}

// ── Client Portal Session (Redis-backed) ───────────

const clientSessionTTL = 24 * time.Hour

func clientSessionKey(token string) string {
	return fmt.Sprintf("session:client:%s", token)
}

// ClientLogin memvalidasi password menggunakan bcrypt via store.CheckClientPassword.
func ClientLogin(clientID, password string) (string, bool) {
	ctx := context.Background()

	ok, err := store.CheckClientPassword(ctx, clientID, password)
	if err != nil {
		logger.Error("Failed to check client password", zap.Error(err))
		return "", false
	}
	if !ok {
		return "", false
	}

	token := generateToken()
	err = store.SetClientSession(ctx, clientSessionKey(token), clientID, clientSessionTTL)
	if err != nil {
		logger.Error("Failed to store client session", zap.Error(err))
		return "", false
	}

	return token, true
}

func IsClientAuthenticated(r *http.Request) (string, bool) {
	cookie, err := r.Cookie("client_session")
	if err != nil {
		return "", false
	}

	ctx := context.Background()
	clientID, err := store.GetSession(ctx, clientSessionKey(cookie.Value))
	if err != nil {
		return "", false
	}

	return clientID, true
}

func SetClientCookie(w http.ResponseWriter, token string) {
	http.SetCookie(w, &http.Cookie{
		Name:     "client_session",
		Value:    token,
		Path:     "/portal",
		HttpOnly: true,
		Secure:   true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   86400,
	})
}

func ClearClientCookie(w http.ResponseWriter) {
	http.SetCookie(w, &http.Cookie{
		Name:     "client_session",
		Value:    "",
		Path:     "/portal",
		HttpOnly: true,
		Secure:   true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   -1,
	})
}

func ClientMiddleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		_, ok := IsClientAuthenticated(r)
		if !ok {
			http.Redirect(w, r, "/portal/login", http.StatusFound)
			return
		}
		next(w, r)
	}
}
