package dashboard

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"html/template"
	"net/http"
	"time"

	"wa-ai/dashboard/auth"

	"github.com/gorilla/mux"
)

// ── Template Cache ──────────────────────────────────

var tmplCache map[string]*template.Template

func initTemplates() {
	tmplCache = map[string]*template.Template{
		"index":            template.Must(template.ParseFiles("dashboard/templates/index.html")),
		"client":           template.Must(template.ParseFiles("dashboard/templates/client.html")),
		"login":            template.Must(template.ParseFiles("dashboard/templates/login.html")),
		"register":         template.Must(template.ParseFiles("dashboard/templates/register.html")),
		"portal_login":     template.Must(template.ParseFiles("dashboard/templates/portal_login.html")),
		"portal_dashboard": template.Must(template.ParseFiles("dashboard/templates/portal_dashboard.html")),
	}
}

func tmpl(name string) *template.Template {
	t, ok := tmplCache[name]
	if !ok {
		panic("template not found: " + name)
	}
	return t
}

// ── CSRF Protection ─────────────────────────────────
//
// Implementasi double-submit cookie pattern:
// 1. Server set cookie __csrf dengan token random
// 2. JS baca cookie dan kirim via header X-CSRF-Token
// 3. Middleware bandingkan keduanya — harus cocok

const csrfCookieName = "__csrf"
const csrfHeaderName = "X-CSRF-Token"

func generateCSRFToken() string {
	b := make([]byte, 32)
	rand.Read(b)
	return hex.EncodeToString(b)
}

// csrfMiddleware memvalidasi CSRF token untuk semua request
// yang mengubah state (POST, PUT, DELETE, PATCH).
func csrfMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Exempt: login form (belum ada session, CSRF tidak relevan)
		exemptPaths := []string{"/login", "/portal/login"}
		for _, p := range exemptPaths {
			if r.URL.Path == p {
				next.ServeHTTP(w, r)
				return
			}
		}

		// GET, HEAD, OPTIONS tidak perlu CSRF
		if r.Method == "GET" || r.Method == "HEAD" || r.Method == "OPTIONS" {
			// Set/refresh CSRF cookie di setiap GET request
			setCSRFCookie(w, r)
			next.ServeHTTP(w, r)
			return
		}

		// Ambil token dari cookie
		cookie, err := r.Cookie(csrfCookieName)
		if err != nil || cookie.Value == "" {
			http.Error(w, `{"error":"CSRF token missing"}`, http.StatusForbidden)
			return
		}

		// Bandingkan dengan header
		headerToken := r.Header.Get(csrfHeaderName)
		if headerToken == "" || headerToken != cookie.Value {
			http.Error(w, `{"error":"CSRF token invalid"}`, http.StatusForbidden)
			return
		}

		next.ServeHTTP(w, r)
	})
}

func setCSRFCookie(w http.ResponseWriter, r *http.Request) {
	// Cek apakah cookie sudah ada — kalau sudah, tidak perlu generate baru
	if _, err := r.Cookie(csrfCookieName); err == nil {
		return
	}

	token := generateCSRFToken()
	http.SetCookie(w, &http.Cookie{
		Name:     csrfCookieName,
		Value:    token,
		Path:     "/",
		HttpOnly: false, // harus false supaya JS bisa baca
		Secure:   true,
		SameSite: http.SameSiteStrictMode,
		MaxAge:   86400,
	})
}

// ── Auth Middleware ─────────────────────────────────

func authMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !auth.IsAuthenticated(r) {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			w.Write([]byte(`{"error":"unauthorized"}`))
			return
		}
		next.ServeHTTP(w, r)
	})
}

func portalAuthMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, ok := auth.IsClientAuthenticated(r)
		if !ok {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			w.Write([]byte(`{"error":"unauthorized"}`))
			return
		}
		next.ServeHTTP(w, r)
	})
}

// ── Health Check ────────────────────────────────────

type healthResponse struct {
	Status    string `json:"status"`
	Timestamp string `json:"timestamp"`
}

func handleHealth(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(healthResponse{
		Status:    "ok",
		Timestamp: time.Now().UTC().Format(time.RFC3339),
	})
}

// ── Server ──────────────────────────────────────────

func NewServer() http.Handler {
	initTemplates()

	r := mux.NewRouter()

	// CSRF middleware — berlaku untuk semua route kecuali yang di-exempt
	r.Use(csrfMiddleware)

	// Health check & public endpoints — exempt dari CSRF (GET only)
	r.HandleFunc("/health", handleHealth).Methods("GET")
	r.HandleFunc("/register", handleRegister).Methods("GET")
	r.HandleFunc("/ws/qr/{client_id}", handleQRWebSocket)

	// /api/register exempt dari CSRF — user belum punya cookie saat registrasi
	r.HandleFunc("/api/register", apiRegister).Methods("POST")

	// Static files
	r.PathPrefix("/static/").Handler(
		http.StripPrefix("/static/",
			http.FileServer(http.Dir("dashboard/static")),
		),
	)

	// Admin auth
	r.HandleFunc("/login", handleLogin).Methods("GET", "POST")
	r.HandleFunc("/logout", handleLogout).Methods("GET")

	// Admin pages
	r.HandleFunc("/", auth.Middleware(handleIndex)).Methods("GET")
	r.HandleFunc("/client/{id}", auth.Middleware(handleClientDetail)).Methods("GET")

	// Admin API
	api := r.PathPrefix("/api").Subrouter()
	api.Use(authMiddleware)
	api.HandleFunc("/clients", apiListClients).Methods("GET")
	api.HandleFunc("/client", apiCreateClient).Methods("POST")
	api.HandleFunc("/client/{id}", apiGetClient).Methods("GET")
	api.HandleFunc("/client/{id}/prompt", apiSetPrompt).Methods("POST")
	api.HandleFunc("/client/{id}/quota", apiSetQuota).Methods("PUT")
	api.HandleFunc("/client/{id}/plan", apiSetPlan).Methods("PUT")
	api.HandleFunc("/client/{id}/usage", apiGetUsage).Methods("GET")
	api.HandleFunc("/client/{id}/reset-usage", apiResetUsage).Methods("POST")
	api.HandleFunc("/client/{id}/upload", apiUploadDoc).Methods("POST")
	api.HandleFunc("/client/{id}/docs", apiListDocs).Methods("GET")
	api.HandleFunc("/client/{id}/docs/{doc_id}", apiDeleteDoc).Methods("DELETE")
	api.HandleFunc("/client/{id}/set-password", apiSetClientPassword).Methods("POST")
	api.HandleFunc("/client/{id}/activate", apiActivateSubscription).Methods("POST")
	api.HandleFunc("/client/{id}/deactivate", apiDeactivateSubscription).Methods("POST")

	// Portal client
	r.HandleFunc("/portal/login", handlePortalLogin).Methods("GET", "POST")
	r.HandleFunc("/portal/logout", handlePortalLogout).Methods("GET")
	r.HandleFunc("/portal", auth.ClientMiddleware(handlePortalDashboard)).Methods("GET")

	// Portal API
	portal := r.PathPrefix("/portal/api").Subrouter()
	portal.Use(portalAuthMiddleware)
	portal.HandleFunc("/info", portalApiInfo).Methods("GET")
	portal.HandleFunc("/docs", portalApiDocs).Methods("GET")
	portal.HandleFunc("/contacts", portalApiContacts).Methods("GET")
	portal.HandleFunc("/contacts/{jid}/history", portalApiHistory).Methods("GET")
	portal.HandleFunc("/contacts/{jid}/export", portalApiExportHistory).Methods("GET")

	return r
}
