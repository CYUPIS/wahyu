package worker

import (
	"context"
	"fmt"
	"strings"
	"time"

	"wa-ai/guardrail"
	"wa-ai/llm"
	"wa-ai/logger"
	"wa-ai/queue"
	"wa-ai/rag"
	"wa-ai/store"
	"wa-ai/usage"
	"wa-ai/whatsapp"

	"go.uber.org/zap"
)

var LLMClient llm.LLM

func Init() {
	LLMClient = llm.NewOpenRouter()
}

// ── Rate Limiter ────────────────────────────────────
//
// Membatasi satu nomor WA agar tidak bisa mengirim lebih dari
// RateLimitMax pesan dalam jendela waktu RateLimitWindow.
// Implementasi pakai Redis sliding window dengan key TTL otomatis.

const (
	RateLimitMax    = 10              // maks pesan per window
	RateLimitWindow = 1 * time.Minute // jendela waktu
)

// isRateLimited return true kalau sender sudah melewati batas.
// Menggunakan Redis INCR + EXPIRE — atomic dan tidak butuh library tambahan.
func isRateLimited(ctx context.Context, clientID string, sender string) bool {
	count, err := store.IncrementRateLimit(ctx, clientID, sender, RateLimitWindow)
	if err != nil {
		// Kalau Redis error, biarkan lewat daripada block semua user
		logger.Warn("Rate limit check failed, allowing message",
			zap.String("client", clientID),
			zap.String("sender", sender),
			zap.Error(err),
		)
		return false
	}
	return count > RateLimitMax
}

// ── Handler ─────────────────────────────────────────

func Handle(ctx context.Context, msg queue.Message) {
	logger.Info("Worker processing message",
		zap.String("sender", msg.Sender),
		zap.String("text", msg.Text),
		zap.String("client", msg.ClientID),
	)

	// Rate limit check — sebelum guardrail supaya spam tidak sampai ke LLM
	if isRateLimited(ctx, msg.ClientID, msg.Sender) {
		logger.Warn("Message rate limited",
			zap.String("client", msg.ClientID),
			zap.String("sender", msg.Sender),
		)
		// Tidak kirim reply supaya spammer tidak tahu mereka di-limit
		return
	}

	// Cek apakah client aktif (belum expired)
	if !store.IsClientActive(ctx, msg.ClientID) {
		logger.Warn("Client inactive or expired, dropping message",
			zap.String("client", msg.ClientID),
		)
		whatsapp.SendMessage(ctx, msg.ClientID, msg.Sender,
			"Layanan Anda sedang tidak aktif. Silakan hubungi admin untuk perpanjang langganan.")
		return
	}

	// Guardrail check
	result := guardrail.Check(msg.Text)
	if !result.Allowed {
		logger.Warn("Message blocked by guardrail",
			zap.String("reason", result.Reason),
		)
		whatsapp.SendMessage(ctx, msg.ClientID, msg.Sender,
			"Maaf, pesan Anda tidak dapat diproses.")
		return
	}

	// Ambil plan client
	plan := store.GetPlan(ctx, msg.ClientID)

	// Quota check + increment secara atomic — mencegah race condition
	allowed, count, err := usage.IncrementAndCheck(ctx, msg.ClientID)
	if err != nil {
		logger.Error("Failed to check/increment quota", zap.Error(err))
	} else if !allowed {
		logger.Warn("Client quota exceeded", zap.String("client", msg.ClientID))
		whatsapp.SendMessage(ctx, msg.ClientID, msg.Sender,
			"Maaf, kuota pesan bulan ini sudah habis. Silakan hubungi admin untuk upgrade paket.")
		return
	} else {
		logger.Info("Usage incremented",
			zap.String("client", msg.ClientID),
			zap.Int64("count", count),
			zap.Int("max", plan.MaxMessages),
		)
	}

	// Ambil system prompt
	systemPrompt, err := store.GetSystemPrompt(ctx, msg.ClientID)
	if err != nil {
		logger.Warn("Failed to get system prompt", zap.Error(err))
		systemPrompt = "Kamu adalah asisten virtual yang membantu menjawab pertanyaan pelanggan dengan ramah."
	}

	// Ambil chat history sesuai plan
	history, err := store.GetChatHistory(ctx, msg.ClientID, msg.Sender, plan.MaxHistory)
	if err != nil {
		logger.Warn("Failed to get chat history", zap.Error(err))
	}

	// Convert history ke format LLM
	var llmHistory []llm.ChatMessage
	for _, h := range history {
		llmHistory = append(llmHistory, llm.ChatMessage{
			Role:    h.Role,
			Content: h.Content,
		})
	}

	// Retrieve context dari Qdrant
	contextText, err := rag.Search(ctx, msg.ClientID, msg.Text)
	if err != nil {
		logger.Warn("RAG retrieval failed", zap.Error(err))
		contextText = ""
	}

	// Build user message
	var userMessage string
	if contextText != "" {
		userMessage = fmt.Sprintf(
			"Informasi yang relevan:\n\n%s\n\nPertanyaan: %s",
			contextText,
			msg.Text,
		)
	} else {
		userMessage = msg.Text
	}

	// Simpan pesan user ke history
	store.AddChatHistory(ctx, msg.ClientID, msg.Sender, "user", msg.Text)

	// Generate response
	reply, err := LLMClient.GenerateWithHistory(ctx, systemPrompt, llmHistory, userMessage)
	if err != nil {
		logger.Error("LLM error", zap.Error(err))
		whatsapp.SendMessage(ctx, msg.ClientID, msg.Sender,
			"Maaf, terjadi kesalahan. Silakan coba lagi.")
		return
	}

	reply = strings.TrimSpace(reply)
	logger.Info("LLM reply generated", zap.String("reply", reply))

	// Simpan reply ke history
	store.AddChatHistory(ctx, msg.ClientID, msg.Sender, "assistant", reply)

	// Kirim reply
	whatsapp.SendMessage(ctx, msg.ClientID, msg.Sender, reply)
}
