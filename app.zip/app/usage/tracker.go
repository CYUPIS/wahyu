package usage

import (
	"context"
	"fmt"
	"strconv"

	"github.com/redis/go-redis/v9"
)

var rdb *redis.Client

func InitRedis(addr string) {
	rdb = redis.NewClient(&redis.Options{
		Addr: addr,
	})
}

const DefaultQuota = 200

func messageKey(clientID string) string {
	return fmt.Sprintf("usage:%s:messages", clientID)
}

func quotaKey(clientID string) string {
	return fmt.Sprintf("usage:%s:quota", clientID)
}

func Increment(ctx context.Context, clientID string) (int64, error) {
	return rdb.Incr(ctx, messageKey(clientID)).Result()
}

func IsAllowed(ctx context.Context, clientID string) (bool, error) {
	quota, err := GetQuota(ctx, clientID)
	if err != nil {
		return false, err
	}

	val, err := rdb.Get(ctx, messageKey(clientID)).Result()
	if err == redis.Nil {
		return true, nil
	}
	if err != nil {
		return false, err
	}

	count, _ := strconv.ParseInt(val, 10, 64)
	return count < quota, nil
}

func SetQuota(ctx context.Context, clientID string, quota int64) error {
	return rdb.Set(ctx, quotaKey(clientID), quota, 0).Err()
}

func GetQuota(ctx context.Context, clientID string) (int64, error) {
	val, err := rdb.Get(ctx, quotaKey(clientID)).Result()
	if err == redis.Nil {
		return DefaultQuota, nil
	}
	if err != nil {
		return 0, err
	}
	quota, _ := strconv.ParseInt(val, 10, 64)
	return quota, nil
}

func Reset(ctx context.Context, clientID string) error {
	return rdb.Del(ctx, messageKey(clientID)).Err()
}

func GetUsage(ctx context.Context, clientID string) (int64, error) {
	val, err := rdb.Get(ctx, messageKey(clientID)).Result()
	if err == redis.Nil {
		return 0, nil
	}
	if err != nil {
		return 0, err
	}
	count, _ := strconv.ParseInt(val, 10, 64)
	return count, nil
}

// IncrementAndCheck melakukan increment dan quota check secara atomic
// menggunakan Redis Lua script — mencegah race condition.
// Return (allowed bool, count int64, err error)
// Kalau melebihi quota, counter otomatis di-decrement kembali.
func IncrementAndCheck(ctx context.Context, clientID string) (bool, int64, error) {
	quota, err := GetQuota(ctx, clientID)
	if err != nil {
		return false, 0, err
	}

	luaScript := redis.NewScript(`
		local count = redis.call('INCR', KEYS[1])
		if count > tonumber(ARGV[1]) then
			redis.call('DECR', KEYS[1])
			return -1
		end
		return count
	`)

	result, err := luaScript.Run(ctx, rdb, []string{messageKey(clientID)}, quota).Int64()
	if err != nil {
		return false, 0, err
	}

	if result == -1 {
		return false, quota, nil // quota exceeded
	}

	return true, result, nil
}
